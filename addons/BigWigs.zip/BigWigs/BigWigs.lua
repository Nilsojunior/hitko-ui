
BigWigs3DB = {
	["namespaces"] = {
		["BigWigs_Bosses_King Rastakhan"] = {
			["profiles"] = {
				["Default"] = {
					[284933] = 967415,
					[285346] = 1032951,
				},
			},
		},
		["BigWigs_Plugins_EchoRename"] = {
		},
		["BigWigs_Bosses_Atal'Dazar Trash"] = {
			["profiles"] = {
				["Default"] = {
					[252687] = 0,
				},
			},
		},
		["BigWigs_Plugins_Alt Power"] = {
			["profiles"] = {
				["fragui"] = {
					["posx"] = 209.77765756032,
					["fontSize"] = 12,
					["fontOutline"] = "",
					["posy"] = 327.110626753558,
					["font"] = "Friz Quadrata TT",
				},
				["xd mw"] = {
					["posx"] = 127.999069939697,
					["posy"] = 236.088373772291,
					["font"] = "Expressway",
				},
				["omg pls"] = {
					["posx"] = 127.999069939697,
					["font"] = "Friz Quadrata TT",
					["posy"] = 236.088373772291,
				},
				["Fragdekay - Twisting Nether"] = {
					["font"] = "Friz Quadrata TT",
					["fontSize"] = 12,
					["fontOutline"] = "",
				},
				["hehe"] = {
					["posx"] = 127.999069939697,
					["posy"] = 236.088373772291,
					["font"] = "Friz Quadrata TT",
				},
				["Rogue BFA BW"] = {
					["posx"] = 127.999069939697,
					["font"] = "Expressway",
					["posy"] = 236.088373772291,
				},
			},
		},
		["BigWigs_Plugins_BossBlock"] = {
		},
		["BigWigs_Bosses_Uu'nat, Harbinger of the Void"] = {
			["profiles"] = {
				["Default"] = {
					[285416] = 0,
					[284851] = 1032439,
					[285307] = 0,
					[285685] = 1032439,
					[285185] = 0,
				},
			},
		},
		["BigWigs_Bosses_N'Zoth, the Corruptor"] = {
			["profiles"] = {
				["Default"] = {
					[312866] = 3130103,
					[318449] = 3064567,
				},
				["Fragnance BW"] = {
					[315772] = 3064567,
					[310184] = 3064567,
					[316711] = 3064567,
				},
			},
		},
		["BigWigs_Plugins_Statistics"] = {
		},
		["BigWigs_Bosses_Hungering Destroyer"] = {
			["profiles"] = {
				["Fragnance BW"] = {
					[329725] = 3064567,
					[334266] = 3064567,
				},
			},
		},
		["BigWigs_Bosses_King's Rest Trash"] = {
			["profiles"] = {
				["Default"] = {
					[271564] = 0,
					[269931] = 0,
					[270865] = 0,
				},
			},
		},
		["BigWigs_Plugins_AltPower"] = {
		},
		["LibDualSpec-1.0"] = {
			["char"] = {
				["Fragimal - EU Mythic Dungeons"] = {
					["enabled"] = false,
				},
				["Jmbo - Tarren Mill"] = {
					["enabled"] = false,
				},
				["Doitpssy - Tarren Mill"] = {
					"Default", -- [1]
					"Default", -- [2]
					"Default", -- [3]
					"xd mw", -- [4]
					["enabled"] = true,
				},
			},
		},
		["BigWigs_Bosses_Ra-den the Despoiled"] = {
			["profiles"] = {
				["Default"] = {
					[306881] = 3130103,
					[316065] = 3130103,
				},
			},
		},
		["BigWigs_Plugins_Wipe"] = {
		},
		["BigWigs_Plugins_AutoReply"] = {
		},
		["BigWigs_Bosses_Loa Council"] = {
			["profiles"] = {
				["Default"] = {
					[285945] = 0,
				},
			},
		},
		["BigWigs_Bosses_Mythrax the Unraveler"] = {
			["profiles"] = {
				["Rogue BFA BW"] = {
					[272404] = 966839,
					[276922] = 967415,
				},
			},
		},
		["BigWigs_Bosses_Queen Azshara"] = {
			["profiles"] = {
				["Default"] = {
					[297371] = 0,
					[297937] = 0,
					[303657] = 0,
					[297372] = 0,
					["custom_off_303657"] = true,
					[300519] = 967415,
					[301078] = 2015479,
					[300428] = 0,
					[297934] = 0,
					[298531] = 0,
					[298756] = 0,
					[298121] = 0,
					[299094] = 0,
					[300743] = 0,
					[298021] = 0,
					[297907] = 0,
					[304475] = 0,
					[298014] = 0,
					[-20480] = 1032951,
				},
			},
		},
		["BigWigs_Bosses_Za'qul, Herald of Ny'alotha"] = {
			["profiles"] = {
				["Default"] = {
					[295444] = 1032951,
					[304733] = 0,
					[292996] = 0,
				},
			},
		},
		["BigWigs_Plugins_Raid Icons"] = {
		},
		["BigWigs_Plugins_Transcriptor"] = {
			["global"] = {
				["ignoredEvents"] = {
				},
			},
		},
		["BigWigs_Bosses_Vectis"] = {
			["profiles"] = {
				["Rogue BFA BW"] = {
					[265127] = 835831,
				},
			},
		},
		["BigWigs_Bosses_Freehold Trash"] = {
			["profiles"] = {
				["Default"] = {
					[257437] = 0,
					[272402] = 0,
					[257908] = 0,
					[274555] = 0,
					[257775] = 0,
				},
			},
		},
		["BigWigs_Bosses_Sire Denathrius"] = {
			["profiles"] = {
				["Fragnance BW"] = {
					["ravage_target"] = 3130103,
					[335873] = 3064039,
				},
			},
		},
		["BigWigs_Bosses_The Golden Serpent"] = {
			["profiles"] = {
				["Default"] = {
					[265910] = 0,
				},
			},
		},
		["BigWigs_Plugins_Respawn"] = {
		},
		["BigWigs_Plugins_Victory"] = {
			["profiles"] = {
				["Hitko"] = {
					["soundName"] = "None",
				},
			},
		},
		["BigWigs_Bosses_High Tinker Mekkatorque"] = {
			["profiles"] = {
				["omg pls"] = {
					["custom_off_sparkbot_marker"] = true,
					["custom_off_286646"] = true,
				},
				["Default"] = {
					[286646] = 1032439,
					["custom_off_sparkbot_marker"] = true,
					["custom_off_286646"] = true,
				},
			},
		},
		["BigWigs_Bosses_Il'gynoth, Corruption Reborn"] = {
			["profiles"] = {
				["Default"] = {
					[313759] = 3130103,
					[311401] = 3129591,
					[309961] = 0,
				},
			},
		},
		["BigWigs_Plugins_Messages"] = {
			["profiles"] = {
				["Hitko"] = {
					["outline"] = "OUTLINE",
					["emphOutline"] = "OUTLINE",
					["disabled"] = true,
					["emphDisabled"] = true,
					["emphFontSize"] = 24,
					["emphFontName"] = "Hitko Font",
					["fontName"] = "Hitko Font",
					["normalPosition"] = {
						"CENTER", -- [1]
						"CENTER", -- [2]
						-0.9999198317527771, -- [3]
						270.0000305175781, -- [4]
					},
				},
			},
		},
		["BigWigs_Bosses_Kurog Grimtotem"] = {
			["profiles"] = {
				["Fragnance BW"] = {
					[374023] = 3130103,
					[391019] = 3064567,
				},
			},
		},
		["BigWigs_Bosses_Shrine of the Storm Trash"] = {
			["profiles"] = {
				["Default"] = {
					[276265] = 0,
					[267977] = 0,
					[268050] = 0,
					[274631] = 0,
				},
			},
		},
		["BigWigs_Bosses_Artificer Xy'mox"] = {
			["profiles"] = {
				["Fragnance BW"] = {
					[340758] = 3064567,
					[335013] = 0,
					[325399] = 0,
					[328789] = 3064567,
					[340788] = 3064567,
				},
			},
		},
		["BigWigs_Bosses_Lady Inerva Darkvein"] = {
			["profiles"] = {
				["Fragnance BW"] = {
					[332664] = 3064567,
					["custom_on_-22618"] = false,
				},
			},
		},
		["BigWigs_Plugins_Sounds"] = {
			["profiles"] = {
				["Hitko"] = {
					["Long"] = {
						["BigWigs_Bosses_Artificer Xy'mox"] = {
							[340788] = "Voice: Cross",
						},
						["BigWigs_Bosses_N'Zoth, the Corruptor"] = {
							[318976] = "Arrow Swoosh",
							[316463] = "Moan",
						},
					},
					["Alert"] = {
						["BigWigs_Bosses_Sanguine Depths Trash"] = {
							[334558] = "Panther",
							[334329] = "Warning",
						},
						["BigWigs_Bosses_Infested Crawg"] = {
							[260292] = "BigWigs: Alert",
						},
						["BigWigs_Bosses_De Other Side Trash"] = {
							[334051] = "Boxing Arena Gong",
						},
					},
				},
			},
		},
		["BigWigs_Bosses_The Hivemind"] = {
			["profiles"] = {
				["Default"] = {
					["custom_on_-20726"] = false,
				},
			},
		},
		["BigWigs_Bosses_Tik'ali"] = {
			["profiles"] = {
				["Default"] = {
					[257582] = 2015479,
				},
			},
		},
		["BigWigs_Bosses_Lady Jaina Proudmoore"] = {
			["profiles"] = {
				["Default"] = {
					[285254] = 2015479,
				},
			},
		},
		["BigWigs_Plugins_Common Auras"] = {
		},
		["BigWigs_Bosses_Aqu'sirr"] = {
			["profiles"] = {
				["Default"] = {
					[264560] = 0,
				},
			},
		},
		["BigWigs_Plugins_Colors"] = {
			["profiles"] = {
				["Hitko"] = {
					["blue"] = {
						["BigWigs_Plugins_Colors"] = {
							["default"] = {
								0.305882352941177, -- [1]
								0.36078431372549, -- [2]
								0.647058823529412, -- [3]
								1, -- [4]
							},
						},
					},
					["cyan"] = {
						["BigWigs_Plugins_Colors"] = {
							["default"] = {
								nil, -- [1]
								nil, -- [2]
								nil, -- [3]
								1, -- [4]
							},
						},
					},
					["barColor"] = {
						["BigWigs_Bosses_Witherbark"] = {
							[164275] = {
								1, -- [1]
								0.2000000178813934, -- [2]
								0.6000000238418579, -- [3]
							},
							[164357] = {
								0, -- [1]
								1, -- [2]
								0, -- [3]
							},
						},
						["BigWigs_Bosses_Vol'kaal"] = {
							[259572] = {
								1, -- [1]
								0.2000000178813934, -- [2]
								0.6000000238418579, -- [3]
							},
						},
						["BigWigs_Bosses_Blight of Galakrond"] = {
							[407159] = {
								0, -- [1]
								1, -- [2]
								0, -- [3]
							},
							[407978] = {
								1, -- [1]
								0.2000000178813934, -- [2]
								0.6000000238418579, -- [3]
							},
						},
						["BigWigs_Bosses_Commander Ulthok"] = {
							[427670] = {
								0, -- [1]
								1, -- [2]
								0, -- [3]
							},
							[427668] = {
								1, -- [1]
								0.2000000178813934, -- [2]
								0.6000000238418579, -- [3]
							},
						},
						["BigWigs_Bosses_The Infinite Dragonflight"] = {
							[416139] = {
								0, -- [1]
								1, -- [2]
								0, -- [3]
							},
						},
						["BigWigs_Bosses_Hungering Destroyer"] = {
							[334266] = {
								0, -- [1]
								0.9098039215686274, -- [2]
								1, -- [3]
							},
							[329725] = {
								0, -- [1]
								1, -- [2]
								0.2392156862745098, -- [3]
							},
						},
						["BigWigs_Bosses_Mindbender Ghur'sha"] = {
							[429037] = {
								1, -- [1]
								0.2000000178813934, -- [2]
								0.6000000238418579, -- [3]
							},
						},
						["BigWigs_Bosses_Raszageth the Storm-Eater"] = {
							[377594] = {
								1, -- [1]
								0, -- [2]
								0, -- [3]
							},
							[377612] = {
								0.6745098233222961, -- [1]
								0, -- [2]
								0.7176470756530762, -- [3]
							},
							[387261] = {
								0.9019608497619629, -- [1]
								0.9803922176361084, -- [2]
								0, -- [3]
							},
							[385574] = {
								1, -- [1]
								0, -- [2]
								0.8784314393997192, -- [3]
							},
						},
						["BigWigs_Bosses_Morchie"] = {
							[406481] = {
								0.250980406999588, -- [1]
								0.3294117748737335, -- [2]
								0.6784313917160034, -- [3]
							},
							[405279] = {
								1, -- [1]
								0.2000000178813934, -- [2]
								0.6000000238418579, -- [3]
							},
							[404364] = {
								0.250980406999588, -- [1]
								0.3294117748737335, -- [2]
								0.6784313917160034, -- [3]
							},
							[404916] = {
								0, -- [1]
								1, -- [2]
								0, -- [3]
							},
							[403891] = {
								1, -- [1]
								0.2000000178813934, -- [2]
								0.6000000238418579, -- [3]
							},
						},
						["BigWigs_Bosses_Rezan"] = {
							[255371] = {
								1, -- [1]
								0.2000000178813934, -- [2]
								0.6000000238418579, -- [3]
							},
							[255434] = {
								0, -- [1]
								1, -- [2]
								0, -- [3]
							},
						},
						["BigWigs_Bosses_Yalnu"] = {
							[169179] = {
								0, -- [1]
								1, -- [2]
								0, -- [3]
							},
						},
						["BigWigs_Bosses_Chronikar"] = {
							[413013] = {
								0, -- [1]
								1, -- [2]
								0, -- [3]
							},
						},
						["BigWigs_Bosses_Iridikron the Stonescaled"] = {
							[414535] = {
								0, -- [1]
								1, -- [2]
								0, -- [3]
							},
							[409879] = {
								1, -- [1]
								0.2000000178813934, -- [2]
								0.6000000238418579, -- [3]
							},
						},
						["BigWigs_Bosses_Ozumat"] = {
							[428407] = {
								0.250980406999588, -- [1]
								0.3294117748737335, -- [2]
								0.6784313917160034, -- [3]
							},
							[428594] = {
								1, -- [1]
								0.2000000178813934, -- [2]
								0.6000000238418579, -- [3]
							},
							[428889] = {
								0.250980406999588, -- [1]
								0.3294117748737335, -- [2]
								0.6784313917160034, -- [3]
							},
							[428530] = {
								0, -- [1]
								1, -- [2]
								0, -- [3]
							},
						},
						["BigWigs_Bosses_Tyr, the Infinite Keeper"] = {
							[400642] = {
								1, -- [1]
								0.2000000178813934, -- [2]
								0.6000000238418579, -- [3]
							},
							[400641] = {
								1, -- [1]
								0.2000000178813934, -- [2]
								0.6000000238418579, -- [3]
							},
							[401248] = {
								0, -- [1]
								1, -- [2]
								0, -- [3]
							},
						},
						["BigWigs_Bosses_Soulbound Goliath"] = {
							[260508] = {
								0, -- [1]
								1, -- [2]
								0, -- [3]
							},
						},
						["BigWigs_Bosses_Fyrakk the Blazing"] = {
							[417443] = {
								0, -- [1]
								1, -- [2]
								0, -- [3]
							},
							[428963] = {
								0, -- [1]
								1, -- [2]
								0, -- [3]
							},
							[425492] = {
								0, -- [1]
								1, -- [2]
								0, -- [3]
							},
						},
						["BigWigs_Bosses_Kurog Grimtotem"] = {
							[374215] = {
								0.8588235974311829, -- [1]
								0, -- [2]
								1, -- [3]
							},
							[391019] = {
								0.8980392813682556, -- [1]
								0, -- [2]
								1, -- [3]
							},
							[374023] = {
								0.7372549176216125, -- [1]
								0, -- [2]
								0.9254902601242065, -- [3]
							},
						},
						["BigWigs_Bosses_Smolderon"] = {
							[421343] = {
								0, -- [1]
								1, -- [2]
								0, -- [3]
							},
							[422577] = {
								0, -- [1]
								1, -- [2]
								0, -- [3]
							},
						},
						["BigWigs_Bosses_Artificer Xy'mox"] = {
							[329107] = {
								0.6941176470588235, -- [1]
								0.6941176470588235, -- [2]
								0.6941176470588235, -- [3]
							},
							[328437] = {
								0.788235294117647, -- [1]
								0.788235294117647, -- [2]
								0.788235294117647, -- [3]
							},
							[340758] = {
								0, -- [1]
								0.9647058823529412, -- [2]
								1, -- [3]
							},
							[328789] = {
								1, -- [1]
								0, -- [2]
								0.03137254901960784, -- [3]
							},
						},
						["BigWigs_Bosses_Yazma"] = {
							[249919] = {
								0, -- [1]
								1, -- [2]
								0, -- [3]
							},
							[259187] = {
								1, -- [1]
								0.2000000178813934, -- [2]
								0.6000000238418579, -- [3]
							},
						},
						["BigWigs_Bosses_Priestess Alun'za"] = {
							[255577] = {
								1, -- [1]
								0.2000000178813934, -- [2]
								0.6000000238418579, -- [3]
							},
							[255579] = {
								0, -- [1]
								1, -- [2]
								0, -- [3]
							},
							[259205] = {
								1, -- [1]
								0.2000000178813934, -- [2]
								0.6000000238418579, -- [3]
							},
						},
						["BigWigs_Bosses_Igira the Cruel"] = {
							[414340] = {
								0, -- [1]
								1, -- [2]
								0, -- [3]
							},
						},
						["BigWigs_Bosses_Lady Inerva Darkvein"] = {
							[332664] = {
								0, -- [1]
								0.6666666666666666, -- [2]
								0.8352941176470589, -- [3]
							},
						},
						["BigWigs_Bosses_Nymue, Weaver of the Cycle"] = {
							[427722] = {
								0, -- [1]
								1, -- [2]
								0, -- [3]
							},
						},
						["BigWigs_Bosses_Smashspite"] = {
							[198073] = {
								1, -- [1]
								0.2000000178813934, -- [2]
								0.6000000238418579, -- [3]
							},
							[198245] = {
								0, -- [1]
								1, -- [2]
								0, -- [3]
							},
						},
						["BigWigs_Bosses_Gnarlroot"] = {
							[424352] = {
								0, -- [1]
								1, -- [2]
								0, -- [3]
							},
						},
						["BigWigs_Bosses_Amalgam of Souls"] = {
							[196078] = {
								1, -- [1]
								0.2000000178813934, -- [2]
								0.6000000238418579, -- [3]
							},
							[195254] = {
								0, -- [1]
								1, -- [2]
								0, -- [3]
							},
						},
						["BigWigs_Plugins_Colors"] = {
							["default"] = {
								0.6000000238418579, -- [1]
								0.6000000238418579, -- [2]
								0.6000000238418579, -- [3]
							},
						},
						["BigWigs_Bosses_Lord and Lady Waycrest"] = {
							[261438] = {
								0, -- [1]
								1, -- [2]
								0, -- [3]
							},
						},
						["BigWigs_Bosses_Dresaron"] = {
							[199345] = {
								1, -- [1]
								0.2000000178813934, -- [2]
								0.6000000238418579, -- [3]
							},
							[191325] = {
								0, -- [1]
								1, -- [2]
								0, -- [3]
							},
						},
						["BigWigs_Bosses_Raal the Gluttonous"] = {
							[264931] = {
								1, -- [1]
								0.2000000178813934, -- [2]
								0.6000000238418579, -- [3]
							},
						},
						["BigWigs_Bosses_Time-Lost Battlefield"] = {
							[410254] = {
								0, -- [1]
								1, -- [2]
								0, -- [3]
							},
							[418046] = {
								1, -- [1]
								0.2000000178813934, -- [2]
								0.6000000238418579, -- [3]
							},
							[418059] = {
								0, -- [1]
								1, -- [2]
								0, -- [3]
							},
						},
						["BigWigs_Bosses_Kurtalos Ravencrest"] = {
							[198635] = {
								0, -- [1]
								1, -- [2]
								0, -- [3]
							},
							[199193] = {
								1, -- [1]
								0.2000000178813934, -- [2]
								0.6000000238418579, -- [3]
							},
						},
						["BigWigs_Bosses_Tindral Sageswift, Seer of the Flame"] = {
							[422000] = {
								0, -- [1]
								1, -- [2]
								0, -- [3]
							},
							[423260] = {
								0, -- [1]
								1, -- [2]
								0, -- [3]
							},
						},
						["BigWigs_Bosses_Stone Legion Generals"] = {
							[342256] = {
								0, -- [1]
								0.8235294117647058, -- [2]
								1, -- [3]
							},
							[344496] = {
								1, -- [1]
								0.5529411764705883, -- [2]
								0, -- [3]
							},
							[333387] = {
								1, -- [1]
								0, -- [2]
								0.04313725490196078, -- [3]
							},
						},
						["BigWigs_Bosses_Volcoross"] = {
							[419054] = {
								0, -- [1]
								1, -- [2]
								0, -- [3]
							},
							[423117] = {
								0, -- [1]
								1, -- [2]
								0, -- [3]
							},
						},
						["BigWigs_Bosses_Council of Dreams"] = {
							[421022] = {
								0, -- [1]
								1, -- [2]
								0, -- [3]
							},
							[420948] = {
								0, -- [1]
								1, -- [2]
								0, -- [3]
							},
							["agonizing_claws_debuff"] = {
								0, -- [1]
								1, -- [2]
								0, -- [3]
							},
						},
						["BigWigs_Bosses_Oakheart"] = {
							[204667] = {
								0, -- [1]
								1, -- [2]
								0, -- [3]
							},
							[204666] = {
								1, -- [1]
								0.2000000178813934, -- [2]
								0.6000000238418579, -- [3]
							},
							[212786] = {
								1, -- [1]
								0.2000000178813934, -- [2]
								0.6000000238418579, -- [3]
							},
							[204611] = {
								0, -- [1]
								1, -- [2]
								0, -- [3]
							},
						},
						["BigWigs_Bosses_Sludgefist"] = {
							[332687] = {
								1, -- [1]
								0, -- [2]
								0.0784313725490196, -- [3]
							},
							[335293] = {
								0.9725490196078431, -- [1]
								1, -- [2]
								0.984313725490196, -- [3]
							},
							[335470] = {
								1, -- [1]
								0, -- [2]
								0.09803921568627451, -- [3]
							},
							[331314] = {
								0, -- [1]
								0.8, -- [2]
								1, -- [3]
							},
							[341193] = {
								1, -- [1]
								0.8627450980392157, -- [2]
								0.3098039215686275, -- [3]
							},
							[340817] = {
								1, -- [1]
								0.6784313725490196, -- [2]
								0, -- [3]
							},
						},
						["BigWigs_Bosses_Illysanna Ravencrest"] = {
							[197696] = {
								1, -- [1]
								0.2000000178813934, -- [2]
								0.6000000238418579, -- [3]
							},
							[197418] = {
								0, -- [1]
								1, -- [2]
								0, -- [3]
							},
						},
						["BigWigs_Bosses_Larodar, Keeper of the Flame"] = {
							[423719] = {
								0, -- [1]
								1, -- [2]
								0, -- [3]
							},
							[418637] = {
								0, -- [1]
								1, -- [2]
								0, -- [3]
							},
						},
						["BigWigs_Bosses_Lady Naz'jar"] = {
							[75683] = {
								1, -- [1]
								0.2000000178813934, -- [2]
								0.6000000238418579, -- [3]
							},
						},
						["BigWigs_Bosses_Archdruid Glaidalis"] = {
							[198379] = {
								0, -- [1]
								1, -- [2]
								0, -- [3]
							},
							[212464] = {
								1, -- [1]
								0.2000000178813934, -- [2]
								0.6000000238418579, -- [3]
							},
						},
						["BigWigs_Bosses_Ancient Protectors"] = {
							[427510] = {
								0, -- [1]
								1, -- [2]
								0, -- [3]
							},
						},
					},
					["flash"] = {
						["BigWigs_Plugins_Colors"] = {
							["default"] = {
								nil, -- [1]
								nil, -- [2]
								nil, -- [3]
								1, -- [4]
							},
						},
					},
					["purple"] = {
						["BigWigs_Plugins_Colors"] = {
							["default"] = {
								1, -- [1]
								0.2000000178813934, -- [2]
								0.6000000238418579, -- [3]
								1, -- [4]
							},
						},
					},
					["barEmphasized"] = {
						["BigWigs_Bosses_Scalecommander Sarkareth"] = {
							[402050] = {
								0.2000000178813934, -- [1]
								1, -- [2]
								1, -- [3]
							},
						},
						["BigWigs_Bosses_Kurog Grimtotem"] = {
							[374215] = {
								0.7215686440467834, -- [1]
								[3] = 1,
							},
							[391019] = {
								0.8784314393997192, -- [1]
								[3] = 1,
							},
							[374023] = {
								0.760784387588501, -- [1]
								[3] = 1,
							},
						},
						["BigWigs_Bosses_Artificer Xy'mox"] = {
							[328789] = {
								[3] = 0.08627450980392157,
							},
							[340758] = {
								0, -- [1]
								0.9137254901960784, -- [2]
								1, -- [3]
							},
							[328437] = {
								0.8274509803921568, -- [1]
								0.8, -- [2]
								0.8666666666666667, -- [3]
							},
						},
						["BigWigs_Bosses_Lady Inerva Darkvein"] = {
							[332664] = {
								0, -- [1]
								0.4156862745098039, -- [2]
								0.8196078431372549, -- [3]
							},
						},
						["BigWigs_Plugins_Colors"] = {
							["default"] = {
								0.6000000238418579, -- [1]
								0.6000000238418579, -- [2]
								0.6000000238418579, -- [3]
							},
						},
						["BigWigs_Bosses_Hungering Destroyer"] = {
							[329725] = {
								0, -- [1]
								1, -- [2]
								0.1607843137254902, -- [3]
							},
							[334266] = {
								0, -- [1]
								0.9921568627450981, -- [2]
								1, -- [3]
							},
							[334522] = {
								0, -- [1]
								1, -- [2]
								0.9019607843137255, -- [3]
							},
						},
						["BigWigs_Bosses_Sludgefist"] = {
							[332687] = {
								[3] = 0.0784313725490196,
							},
							[335293] = {
								0.9764705882352941, -- [1]
								1, -- [2]
								0.9372549019607843, -- [3]
							},
							[335470] = {
								[3] = 0.1647058823529412,
							},
							[331314] = {
								0, -- [1]
								0.8117647058823529, -- [2]
								1, -- [3]
							},
							[340817] = {
								nil, -- [1]
								0.611764705882353, -- [2]
							},
						},
						["BigWigs_Bosses_Stone Legion Generals"] = {
							[342256] = {
								0, -- [1]
								0.9254901960784314, -- [2]
								1, -- [3]
							},
							[344496] = {
								nil, -- [1]
								0.5098039215686274, -- [2]
							},
							[333387] = {
								[3] = 0.05882352941176471,
							},
						},
						["BigWigs_Bosses_Raszageth the Storm-Eater"] = {
							[377594] = {
								[3] = 0.0784313753247261,
							},
							[377612] = {
								[3] = 1,
							},
							[387261] = {
								0.9803922176361084, -- [1]
								0.9803922176361084, -- [2]
							},
							[385574] = {
								[3] = 0.8784314393997192,
							},
						},
					},
					["green"] = {
						["BigWigs_Plugins_Colors"] = {
							["default"] = {
								0, -- [1]
								nil, -- [2]
								0, -- [3]
								1, -- [4]
							},
						},
					},
					["barTextShadow"] = {
						["BigWigs_Plugins_Colors"] = {
							["default"] = {
								nil, -- [1]
								nil, -- [2]
								nil, -- [3]
								0, -- [4]
							},
						},
					},
					["barBackground"] = {
						["BigWigs_Plugins_Colors"] = {
							["default"] = {
								0.0313725508749485, -- [1]
								0.0313725508749485, -- [2]
								0.0313725508749485, -- [3]
								0.4000000059604645, -- [4]
							},
						},
					},
					["orange"] = {
						["BigWigs_Plugins_Colors"] = {
							["default"] = {
								nil, -- [1]
								nil, -- [2]
								nil, -- [3]
								1, -- [4]
							},
						},
					},
					["red"] = {
						["BigWigs_Plugins_Colors"] = {
							["default"] = {
								0.7803921568627451, -- [1]
								0.07450980392156863, -- [2]
								0.1568627450980392, -- [3]
								1, -- [4]
							},
						},
					},
				},
			},
		},
		["BigWigs_Plugins_Countdown"] = {
			["profiles"] = {
				["Hitko"] = {
					["outline"] = "OUTLINE",
					["fontSize"] = 60,
					["fontColor"] = {
						["g"] = 1,
						["b"] = 1,
					},
					["position"] = {
						"CENTER", -- [1]
						"CENTER", -- [2]
						-3.999941825866699, -- [3]
						245, -- [4]
					},
					["fontName"] = "Hitko Font",
					["bossCountdowns"] = {
						["BigWigs_Bosses_Uu'nat, Harbinger of the Void"] = {
							[285685] = "deDE: Default (Female)",
						},
						["BigWigs_Bosses_N'Zoth, the Corruptor"] = {
							[318976] = "deDE: Default (Female)",
						},
					},
				},
			},
		},
		["BigWigs_Bosses_The MOTHERLODE!! Trash"] = {
			["profiles"] = {
				["Default"] = {
					[263628] = 0,
					[262412] = 0,
				},
			},
		},
		["BigWigs_Bosses_Sergeant Bainbridge"] = {
			["profiles"] = {
				["Default"] = {
					[257585] = 0,
				},
			},
		},
		["BigWigs_Bosses_Scalecommander Sarkareth"] = {
			["profiles"] = {
				["Fragnance BW"] = {
					[402050] = 3129591,
				},
			},
		},
		["BigWigs_Bosses_Adderis and Aspix"] = {
			["profiles"] = {
				["Default"] = {
					[263246] = 1032439,
				},
			},
		},
		["BigWigs_Plugins_InfoBox"] = {
		},
		["BigWigs_Plugins_Bars"] = {
			["profiles"] = {
				["Default"] = {
					["BigWigsAnchor_width"] = 220.0000762939453,
					["BigWigsEmphasizeAnchor_width"] = 320.0000305175781,
					["BigWigsEmphasizeAnchor_height"] = 22.0000057220459,
					["BigWigsAnchor_height"] = 15.99990844726563,
				},
				["Hitko"] = {
					["BigWigsEmphasizeAnchor_y"] = 215.2886644530026,
					["BigWigsAnchor_width"] = 423.9999389648438,
					["BigWigsAnchor_y"] = 154,
					["nameplateOffsetY"] = 15,
					["BigWigsAnchor_x"] = 1065,
					["texture"] = "Hitko Bar Dark",
					["barStyle"] = "ElvUI",
					["BigWigsEmphasizeAnchor_height"] = 17.00000190734863,
					["growup"] = true,
					["BigWigsEmphasizeAnchor_width"] = 263.0000305175781,
					["nameplateWidth"] = 162,
					["BigWigsAnchor_height"] = 16.99996948242188,
					["visibleBarLimitEmph"] = 4,
					["fontName"] = "Hitko Font",
					["fontSizeEmph"] = 10,
					["BigWigsEmphasizeAnchor_x"] = 596,
					["outline"] = "OUTLINE",
					["nameplateHeight"] = 8,
				},
			},
		},
		["BigWigs_Bosses_Stone Legion Generals"] = {
			["profiles"] = {
				["Fragnance BW"] = {
					[333387] = 3129591,
					[334765] = 0,
					[342985] = 0,
					[342256] = 3064567,
					[344496] = 3064567,
				},
			},
		},
		["BigWigs_Plugins_Super Emphasize"] = {
			["profiles"] = {
				["fragui"] = {
					["font"] = "Friz Quadrata TT",
				},
				["xd mw"] = {
					["outline"] = "OUTLINE",
					["font"] = "Expressway",
					["fontColor"] = {
						["r"] = 0.992156862745098,
						["g"] = 0.984313725490196,
						["b"] = 1,
					},
					["fontName"] = "Expressway",
				},
				["omg pls"] = {
					["outline"] = "NONE",
					["font"] = "Friz Quadrata TT",
					["fontName"] = "Expressway",
				},
				["Fragdekay - Twisting Nether"] = {
					["font"] = "Friz Quadrata TT",
				},
				["hehe"] = {
					["fontName"] = "Expressway",
					["font"] = "Friz Quadrata TT",
				},
				["Rogue BFA BW"] = {
					["outline"] = "OUTLINE",
					["fontSize"] = 45,
					["fontColor"] = {
						["r"] = 0.992156862745098,
						["g"] = 0.984313725490196,
						["b"] = 1,
					},
					["fontName"] = "Expressway",
					["font"] = "Expressway",
				},
			},
		},
		["BigWigs_Bosses_Orgozoa"] = {
			["profiles"] = {
				["Default"] = {
					[305057] = 967415,
					[305048] = 2015991,
				},
			},
		},
		["BigWigs_Bosses_The Restless Cabal"] = {
			["profiles"] = {
				["Default"] = {
					["custom_off_-19060"] = true,
					[282407] = 0,
					["berserk"] = 0,
					[282386] = 0,
				},
			},
		},
		["BigWigs_Bosses_Sludgefist"] = {
			["profiles"] = {
				["Fragnance BW"] = {
					[335470] = 3064567,
					[340817] = 3064567,
					[331314] = 3064567,
					[332687] = 3064567,
				},
			},
		},
		["BigWigs_Bosses_Avatar of Sethraliss"] = {
			["profiles"] = {
				["Default"] = {
					[273677] = 0,
				},
			},
		},
		["BigWigs_Plugins_Proximity"] = {
			["profiles"] = {
				["Hitko"] = {
					["posx"] = 350.0443216416497,
					["font"] = "Interface\\Addons\\Tukui\\medias\\fonts\\normal_font.ttf",
					["disabled"] = true,
					["height"] = 110.0000686645508,
					["posy"] = 70.2215856935909,
					["width"] = 122.0000534057617,
				},
			},
		},
		["BigWigs_Bosses_G'huun"] = {
			["profiles"] = {
				["Rogue BFA BW"] = {
					["stages"] = 0,
					[270373] = 1032375,
				},
				["Default"] = {
					[270373] = 1032439,
				},
			},
		},
		["BigWigs_Plugins_Pull"] = {
		},
		["BigWigs_Bosses_Jadefire Masters Horde"] = {
			["profiles"] = {
				["Default"] = {
					[284656] = 1032951,
					[282030] = 1032951,
				},
			},
		},
	},
	["profileKeys"] = {
		["Fraggz - Alonsus"] = "Default",
		["Fraggymonk - Twisting Nether"] = "Default",
		["Fragnance - Stormreaver"] = "Default",
		["Fragnance - Kazzak"] = "Default",
		["Fragmage - Kazzak"] = "Default",
		["Jmybtw - Twisting Nether"] = "Default",
		["Fragnancedh - Valley of Heroes - EU"] = "Default",
		["Songname - Twisting Nether"] = "Default",
		["Fragmonk - Valley of Heroes - EU"] = "Default",
		["Ahhnummertva - Twisting Nether"] = "Default",
		["Fragura - EU Mythic Dungeons"] = "Default",
		["Jimboom - Tarren Mill"] = "Default",
		["Fragnance - The Maelstrom"] = "Default",
		["Fragnance - Alonsus"] = "Default",
		["Fraggi - EU Mythic Dungeons"] = "Default",
		["Fragg - Alonsus"] = "Default",
		["Sliddy - Lycanthoth"] = "Default",
		["Fraggilock - Valley of Heroes - EU"] = "Default",
		["Ravage - Valley of Heroes - EU"] = "Default",
		["Fraggym - Valley of Heroes - EU"] = "Default",
		["Phynn - Alonsus"] = "Default",
		["Daddycoach - Twisting Nether"] = "Default",
		["Fragnance - Tarren Mill"] = "Default",
		["Fragdh - Mythic Dungeon Heroes - EU"] = "Default",
		["Fraggymonk - Tarren Mill"] = "Default",
		["Fraggymonk - Kazzak"] = "Default",
		["Fragnam - EU Mythic Dungeons"] = "Default",
		["Fraggihontas - Twisting Nether"] = "Default",
		["Landqvist - Twisting Nether"] = "Default",
		["Fragkyri - EU Mythic Dungeons"] = "Default",
		["Fragnancedw - Mythic Dungeon Heroes - EU"] = "Default",
		["Fraggi - The Maelstrom"] = "Default",
		["Sweedspot - Twisting Nether"] = "Default",
		["Hitkö - Azralon"] = "Hitko",
		["Hitkodk - Illidan"] = "Hitko",
		["Fragnam - Tarren Mill"] = "Default",
		["Alyfila - Alonsus"] = "Default",
		["Fraggichu - Tarren Mill"] = "Default",
		["Fragsp - Mythic Dungeon Heroes - EU"] = "Default",
		["Fraggi - Twisting Nether"] = "Default",
		["Slìddjur - Twisting Nether"] = "Default",
		["Fraghont - EU Mythic Dungeons"] = "Default",
		["Fraggz - The Maelstrom"] = "Default",
		["Fraggilock - Tarren Mill"] = "Default",
		["Ravage - Al'Akir"] = "Default",
		["Fraggilock - Twisting Nether"] = "Default",
		["Fraggywrap - EU Mythic Dungeons"] = "Default",
		["Fraggi - Mythic Dungeon Heroes - EU"] = "Default",
		["Hitkopally - Azralon"] = "Hitko",
		["Jmmy - Tarren Mill"] = "Default",
		["Fragrr - Mythic Dungeon Heroes - EU"] = "Default",
		["Djimmy - Tarren Mill"] = "Default",
		["Fraggihontas - EU Mythic Dungeons"] = "Default",
		["Fragnance - Twisting Nether"] = "Default",
		["Fragmclovin - Mythic Dungeon Heroes - EU"] = "Default",
		["Fragesus - EU Mythic Dungeons"] = "Default",
		["Fraggi - Alonsus"] = "Default",
		["Sicklikeme - Twisting Nether"] = "Default",
		["Fraggojimi - Twisting Nether"] = "Default",
		["Fraggilock - Ragnaros"] = "Default",
		["Sicklikemoo - Tarren Mill"] = "Default",
		["Helloimjmy - Twisting Nether"] = "Default",
		["Nitrate - Genjuros"] = "Default",
		["Fragmage - Twisting Nether"] = "Default",
		["Doitpssy - Tarren Mill"] = "Default",
		["Fragdkk - Mythic Dungeon Heroes - EU"] = "Default",
		["Slíddjur - Draenor"] = "Default",
		["Fittast - Twisting Nether"] = "Default",
		["Fraggeh - Mythic Dungeon Heroes - EU"] = "Default",
		["Fragr - Mythic Dungeon Heroes - EU"] = "Default",
		["Fragcid - Mythic Dungeon Heroes - EU"] = "Default",
		["Daddyfragdw - Twisting Nether"] = "Default",
		["Rangedferal - Twisting Nether"] = "Default",
		["Slíddjur - Twisting Nether"] = "Default",
		["Fraggihontas - Mythic Dungeon Heroes - EU"] = "Default",
		["Fraggigrip - Twisting Nether"] = "Default",
		["Hitkodekay - Azralon"] = "Hitko",
		["Fragnancè - Valley of Heroes - EU"] = "Default",
		["Fraggytaunt - Kazzak"] = "Default",
		["Fragrogue - Mythic Dungeon Heroes - EU"] = "Default",
		["Hitkodh - Azralon"] = "Hitko",
		["Fragnance - Mythic Dungeon Heroes - EU"] = "Default",
		["Fragslamsoak - Stormreaver"] = "Default",
		["Fragre - Mythic Dungeon Heroes - EU"] = "Default",
		["Sicklikeme - C'Thun"] = "Default",
		["Daddyfrag - Valley of Heroes - EU"] = "Default",
		["Fragssiah - EU Mythic Dungeons"] = "Default",
		["Fragnance - Ravencrest"] = "Default",
		["Hítko - Azralon"] = "Default",
		["Fraggyspears - EU Mythic Dungeons"] = "Default",
		["Fraggydh - Valley of Heroes - EU"] = "Default",
		["Fragdk - Mythic Dungeon Heroes - EU"] = "Default",
		["Fraggytaunt - Twisting Nether"] = "Default",
		["Lilfilth - Tarren Mill"] = "Default",
		["Fragbag - EU Mythic Dungeons"] = "Default",
		["Frangry - EU Mythic Dungeons"] = "Default",
		["Fraglock - Valley of Heroes - EU"] = "Default",
		["Fragdhh - Mythic Dungeon Heroes - EU"] = "Default",
	},
	["global"] = {
		["watchedMovies"] = {
			[-2002] = true,
			[952] = true,
			[956] = true,
			[958] = true,
			[295] = true,
			[964] = true,
			[-1152] = true,
			[-1345] = true,
			[-2170] = true,
			[-909] = true,
			[-917] = true,
			[549] = true,
			[992] = true,
			[-437] = true,
			[-1153] = true,
			[876] = true,
			[-1358] = true,
			[-1004] = true,
			[-2000] = true,
			[-2004] = true,
			[-323] = true,
			[656] = true,
			[-2233] = true,
			[-914] = true,
			[-575] = true,
			[927] = true,
			[991] = true,
			[-607] = true,
			[-609] = true,
			[294] = true,
			[1003] = true,
			[682] = true,
			[686] = true,
			[875] = true,
			[-1352] = {
				[2] = true,
			},
			[-1151] = true,
			[688] = true,
			[-1597] = true,
			[886] = true,
			[957] = true,
		},
	},
	["profiles"] = {
		["Default"] = {
		},
		["Hitko"] = {
			["flash"] = false,
		},
	},
}
BigWigsIconDB = {
	["minimapPos"] = 104.588892908324,
	["hide"] = true,
}
BigWigsStatsDB = {
	[1448] = {
		[1392] = {
			["normal"] = {
				["best"] = 140.753000000001,
				["kills"] = 18,
			},
			["heroic"] = {
				["kills"] = 56,
				["wipes"] = 7,
				["best"] = 43.2860000000219,
			},
			["mythic"] = {
				["kills"] = 49,
				["wipes"] = 22,
				["best"] = 40.9780000000028,
			},
			["LFR"] = {
				["best"] = 22.6650000000082,
				["kills"] = 9,
			},
		},
		[1396] = {
			["normal"] = {
				["kills"] = 14,
				["best"] = 139.487999999983,
				["wipes"] = 1,
			},
			["heroic"] = {
				["kills"] = 57,
				["best"] = 66.5429999999997,
				["wipes"] = 6,
			},
			["mythic"] = {
				["kills"] = 51,
				["wipes"] = 19,
				["best"] = 66.8319999999949,
			},
			["LFR"] = {
				["kills"] = 11,
				["best"] = 51.4320000000007,
				["wipes"] = 1,
			},
		},
		[1438] = {
			["heroic"] = {
				["kills"] = 132,
				["wipes"] = 182,
				["best"] = 106.385,
			},
			["normal"] = {
				["kills"] = 68,
				["wipes"] = 35,
				["best"] = 81.2699999999968,
			},
			["mythic"] = {
				["kills"] = 35,
				["wipes"] = 585,
				["best"] = 189.737999999998,
			},
			["LFR"] = {
				["kills"] = 7,
				["wipes"] = 3,
				["best"] = 60.2970000000205,
			},
		},
		[1427] = {
			["normal"] = {
				["kills"] = 13,
				["best"] = 181.986999999999,
				["wipes"] = 1,
			},
			["mythic"] = {
				["kills"] = 50,
				["wipes"] = 37,
				["best"] = 84.4100000000035,
			},
			["heroic"] = {
				["kills"] = 55,
				["best"] = 84.0550000000003,
				["wipes"] = 19,
			},
			["LFR"] = {
				["best"] = 76.0130000000063,
				["kills"] = 7,
			},
		},
		[1432] = {
			["normal"] = {
				["best"] = 149.572999999975,
				["kills"] = 16,
			},
			["heroic"] = {
				["kills"] = 59,
				["best"] = 85.1590000000006,
				["wipes"] = 1,
			},
			["mythic"] = {
				["kills"] = 48,
				["wipes"] = 17,
				["best"] = 119.534,
			},
			["LFR"] = {
				["best"] = 42.323000000004,
				["kills"] = 12,
			},
		},
		[1394] = {
			["normal"] = {
				["best"] = 153.777000000002,
				["kills"] = 13,
			},
			["heroic"] = {
				["kills"] = 59,
				["wipes"] = 29,
				["best"] = 108.425,
			},
			["mythic"] = {
				["kills"] = 43,
				["wipes"] = 116,
				["best"] = 134.475999999995,
			},
			["LFR"] = {
				["best"] = 105.934999999998,
				["kills"] = 8,
			},
		},
		[1425] = {
			["normal"] = {
				["best"] = 77.6169999999984,
				["kills"] = 15,
			},
			["heroic"] = {
				["kills"] = 54,
				["best"] = 35.3269999999902,
				["wipes"] = 16,
			},
			["mythic"] = {
				["kills"] = 51,
				["wipes"] = 10,
				["best"] = 40.2920000000013,
			},
			["LFR"] = {
				["best"] = 24.255999999994,
				["kills"] = 11,
			},
		},
		[1372] = {
			["mythic"] = {
				["kills"] = 49,
				["wipes"] = 126,
				["best"] = 145.916000000085,
			},
			["heroic"] = {
				["kills"] = 53,
				["best"] = 138.462,
				["wipes"] = 13,
			},
			["normal"] = {
				["kills"] = 13,
				["best"] = 244.756999999998,
				["wipes"] = 9,
			},
			["LFR"] = {
				["best"] = 47.5050000000047,
				["kills"] = 10,
			},
		},
		[1391] = {
			["normal"] = {
				["kills"] = 11,
				["best"] = 87.8550000000105,
				["wipes"] = 2,
			},
			["heroic"] = {
				["kills"] = 55,
				["wipes"] = 70,
				["best"] = 54.9020000000019,
			},
			["mythic"] = {
				["kills"] = 47,
				["wipes"] = 83,
				["best"] = 55.1009999999951,
			},
			["LFR"] = {
				["best"] = 18.7979999999807,
				["kills"] = 8,
			},
		},
		[1395] = {
			["normal"] = {
				["kills"] = 28,
				["best"] = 191.817999999999,
				["wipes"] = 7,
			},
			["mythic"] = {
				["kills"] = 42,
				["wipes"] = 251,
				["best"] = 164.300999999978,
			},
			["heroic"] = {
				["kills"] = 81,
				["wipes"] = 34,
				["best"] = 141.811,
			},
			["LFR"] = {
				["best"] = 138.694000000018,
				["kills"] = 9,
			},
		},
		[1426] = {
			["normal"] = {
				["best"] = 313.608,
				["kills"] = 14,
			},
			["mythic"] = {
				["kills"] = 50,
				["best"] = 393.517,
				["wipes"] = 16,
			},
			["heroic"] = {
				["kills"] = 51,
				["best"] = 277.595999999961,
				["wipes"] = 3,
			},
			["LFR"] = {
				["best"] = 223.42300000001,
				["kills"] = 10,
			},
		},
		[1433] = {
			["normal"] = {
				["kills"] = 12,
				["best"] = 256.338,
				["wipes"] = 7,
			},
			["mythic"] = {
				["kills"] = 43,
				["wipes"] = 48,
				["best"] = 162.365000000005,
			},
			["heroic"] = {
				["kills"] = 47,
				["wipes"] = 38,
				["best"] = 127.103999999999,
			},
			["LFR"] = {
				["best"] = 174.11500000002,
				["kills"] = 7,
			},
		},
		[1447] = {
			["normal"] = {
				["kills"] = 15,
				["best"] = 132.32799999998,
				["wipes"] = 9,
			},
			["mythic"] = {
				["kills"] = 46,
				["wipes"] = 373,
				["best"] = 65.4349999999977,
			},
			["heroic"] = {
				["kills"] = 53,
				["wipes"] = 21,
				["best"] = 84.8990000000013,
			},
			["LFR"] = {
				["best"] = 51.2900000000082,
				["kills"] = 9,
			},
		},
	},
	[2096] = {
		[2328] = {
			["heroic"] = {
				["kills"] = 3,
				["best"] = 276.255999999994,
				["wipes"] = 16,
			},
			["mythic"] = {
				["kills"] = 6,
				["wipes"] = 190,
				["best"] = 392.7649999999994,
			},
		},
		[2332] = {
			["heroic"] = {
				["kills"] = 4,
				["best"] = 267.385000000009,
				["wipes"] = 4,
			},
			["mythic"] = {
				["kills"] = 4,
				["wipes"] = 319,
				["best"] = 560.5910000000149,
			},
		},
	},
	[1205] = {
		[1122] = {
			["heroic"] = {
				["kills"] = 53,
				["best"] = 228.286999999997,
				["wipes"] = 2,
			},
			["normal"] = {
				["best"] = 128.776000000001,
				["kills"] = 8,
			},
			["mythic"] = {
				["kills"] = 30,
				["best"] = 214.584000000003,
				["wipes"] = 3,
			},
			["LFR"] = {
				["best"] = 39.5909999999858,
				["kills"] = 20,
			},
		},
		[959] = {
			["normal"] = {
				["kills"] = 7,
				["best"] = 96.656,
				["wipes"] = 8,
			},
			["heroic"] = {
				["kills"] = 57,
				["wipes"] = 209,
				["best"] = 216.422000000002,
			},
			["mythic"] = {
				["kills"] = 40,
				["wipes"] = 261,
				["best"] = 74.5179999999964,
			},
			["LFR"] = {
				["kills"] = 25,
				["best"] = 19.7050000000163,
				["wipes"] = 6,
			},
		},
		[1123] = {
			["heroic"] = {
				["kills"] = 61,
				["wipes"] = 28,
				["best"] = 143.381999999998,
			},
			["normal"] = {
				["kills"] = 10,
				["best"] = 81.7730000000002,
				["wipes"] = 4,
			},
			["mythic"] = {
				["kills"] = 23,
				["wipes"] = 11,
				["best"] = 118.039000000001,
			},
			["LFR"] = {
				["best"] = 30.6600000000035,
				["kills"] = 18,
			},
		},
		[1202] = {
			["heroic"] = {
				["kills"] = 58,
				["wipes"] = 16,
				["best"] = 95.0729999999894,
			},
			["mythic"] = {
				["kills"] = 27,
				["wipes"] = 31,
				["best"] = 104.770999999979,
			},
			["normal"] = {
				["kills"] = 10,
				["wipes"] = 8,
				["best"] = 38.5990000000002,
			},
			["LFR"] = {
				["kills"] = 26,
				["wipes"] = 1,
				["best"] = 15.69200000001,
			},
		},
		[1161] = {
			["heroic"] = {
				["kills"] = 55,
				["wipes"] = 9,
				["best"] = 118.028000000006,
			},
			["mythic"] = {
				["kills"] = 23,
				["wipes"] = 25,
				["best"] = 133.741,
			},
			["normal"] = {
				["kills"] = 9,
				["best"] = 50.3119999999999,
				["wipes"] = 1,
			},
			["LFR"] = {
				["kills"] = 26,
				["best"] = 36.8550000000105,
				["wipes"] = 2,
			},
		},
		[1154] = {
			["heroic"] = {
				["kills"] = 59,
				["wipes"] = 40,
				["best"] = 408.868999999992,
			},
			["normal"] = {
				["best"] = 323.113,
				["kills"] = 7,
			},
			["mythic"] = {
				["kills"] = 12,
				["wipes"] = 142,
				["best"] = 470.583000000001,
			},
			["LFR"] = {
				["best"] = 137.962,
				["kills"] = 21,
			},
		},
		[1203] = {
			["heroic"] = {
				["kills"] = 59,
				["wipes"] = 82,
				["best"] = 305.620999999999,
			},
			["mythic"] = {
				["kills"] = 20,
				["wipes"] = 191,
				["best"] = 267.063,
			},
			["normal"] = {
				["kills"] = 10,
				["wipes"] = 6,
				["best"] = 85.119999999999,
			},
			["LFR"] = {
				["kills"] = 19,
				["best"] = 47.2869999999821,
				["wipes"] = 1,
			},
		},
		[1162] = {
			["heroic"] = {
				["kills"] = 63,
				["wipes"] = 49,
				["best"] = 132.25,
			},
			["normal"] = {
				["kills"] = 6,
				["wipes"] = 1,
				["best"] = 41.0230000000001,
			},
			["mythic"] = {
				["kills"] = 22,
				["wipes"] = 24,
				["best"] = 214.823,
			},
			["LFR"] = {
				["best"] = 18.420999999973,
				["kills"] = 17,
			},
		},
		[1155] = {
			["heroic"] = {
				["kills"] = 56,
				["best"] = 121.970000000001,
				["wipes"] = 11,
			},
			["mythic"] = {
				["kills"] = 21,
				["wipes"] = 33,
				["best"] = 137.055,
			},
			["normal"] = {
				["kills"] = 12,
				["best"] = 80.2550000000001,
				["wipes"] = 37,
			},
			["LFR"] = {
				["kills"] = 22,
				["best"] = 36.6969999999856,
				["wipes"] = 5,
			},
		},
		[1147] = {
			["heroic"] = {
				["kills"] = 47,
				["wipes"] = 38,
				["best"] = 175.433000000001,
			},
			["normal"] = {
				["kills"] = 7,
				["wipes"] = 5,
				["best"] = 85.8090000000002,
			},
			["mythic"] = {
				["kills"] = 26,
				["wipes"] = 48,
				["best"] = 185.153,
			},
			["LFR"] = {
				["best"] = 18.7109999999811,
				["kills"] = 18,
			},
		},
	},
	[2164] = {
		[2354] = {
			["mythic"] = {
				["kills"] = 24,
				["wipes"] = 47,
				["best"] = 203.3460000000196,
			},
			["normal"] = {
				["best"] = 80.81299999999464,
				["kills"] = 1,
			},
			["heroic"] = {
				["kills"] = 7,
				["wipes"] = 2,
				["best"] = 177.0289999999986,
			},
		},
		[2351] = {
			["mythic"] = {
				["kills"] = 23,
				["wipes"] = 51,
				["best"] = 318.5030000000006,
			},
			["normal"] = {
				["best"] = 161.4470000000001,
				["kills"] = 1,
			},
			["heroic"] = {
				["kills"] = 9,
				["best"] = 190.9099999999999,
				["wipes"] = 2,
			},
		},
		[2359] = {
			["mythic"] = {
				["kills"] = 25,
				["wipes"] = 34,
				["best"] = 318.759,
			},
			["normal"] = {
				["best"] = 149.791000000012,
				["kills"] = 1,
			},
			["heroic"] = {
				["best"] = 198.6049999999996,
				["kills"] = 9,
			},
		},
		[2353] = {
			["mythic"] = {
				["kills"] = 25,
				["best"] = 188.2169999999896,
				["wipes"] = 4,
			},
			["normal"] = {
				["best"] = 140.3850000000093,
				["kills"] = 1,
			},
			["heroic"] = {
				["best"] = 149.8190000000031,
				["kills"] = 13,
			},
		},
		[2347] = {
			["mythic"] = {
				["kills"] = 30,
				["best"] = 176.1209999999992,
				["wipes"] = 4,
			},
			["normal"] = {
				["best"] = 127.8540000000066,
				["kills"] = 1,
			},
			["heroic"] = {
				["best"] = 149.1350000000093,
				["kills"] = 8,
			},
		},
		[2352] = {
			["mythic"] = {
				["kills"] = 27,
				["best"] = 158.0910000000004,
				["wipes"] = 1,
			},
			["normal"] = {
				["best"] = 107.2390000000014,
				["kills"] = 1,
			},
			["heroic"] = {
				["kills"] = 15,
				["best"] = 134.1659999999974,
				["wipes"] = 2,
			},
		},
		[2349] = {
			["mythic"] = {
				["kills"] = 26,
				["wipes"] = 196,
				["best"] = 421.1469999999972,
			},
			["normal"] = {
				["best"] = 137.5859999999957,
				["kills"] = 1,
			},
			["heroic"] = {
				["kills"] = 8,
				["best"] = 197.755000000001,
				["wipes"] = 2,
			},
		},
		[2361] = {
			["mythic"] = {
				["kills"] = 19,
				["wipes"] = 396,
				["best"] = 542.4790000000503,
			},
			["normal"] = {
				["kills"] = 1,
				["wipes"] = 2,
				["best"] = 236.2810000000027,
			},
			["heroic"] = {
				["kills"] = 14,
				["wipes"] = 12,
				["best"] = 325.2700000000004,
			},
		},
	},
	[2569] = {
		[2529] = {
			["heroic"] = {
				["kills"] = 6,
				["best"] = 144.1039999999994,
				["wipes"] = 1,
			},
			["mythic"] = {
				["kills"] = 8,
				["wipes"] = 6,
				["best"] = 249.5789999999997,
			},
		},
		[2522] = {
			["heroic"] = {
				["best"] = 113.4040000000023,
				["kills"] = 8,
			},
			["mythic"] = {
				["kills"] = 6,
				["wipes"] = 1,
				["best"] = 195.112000000001,
			},
		},
		[2530] = {
			["heroic"] = {
				["kills"] = 6,
				["best"] = 167.4430000000066,
				["wipes"] = 1,
			},
			["mythic"] = {
				["kills"] = 8,
				["wipes"] = 21,
				["best"] = 244.0859999999957,
			},
		},
		[2523] = {
			["heroic"] = {
				["kills"] = 6,
				["wipes"] = 5,
				["best"] = 229.6970000000001,
			},
			["mythic"] = {
				["kills"] = 7,
				["wipes"] = 143,
				["best"] = 407.3009999999995,
			},
		},
		[2524] = {
			["heroic"] = {
				["kills"] = 5,
				["best"] = 50.20600000000559,
				["wipes"] = 1,
			},
			["mythic"] = {
				["kills"] = 6,
				["best"] = 139.5060000000012,
				["wipes"] = 2,
			},
		},
		[2532] = {
			["heroic"] = {
				["kills"] = 5,
				["best"] = 143.7490000000034,
				["wipes"] = 2,
			},
			["mythic"] = {
				["kills"] = 6,
				["wipes"] = 32,
				["best"] = 274.5870000000032,
			},
		},
		[2525] = {
			["heroic"] = {
				["kills"] = 6,
				["best"] = 187.2200000000012,
				["wipes"] = 4,
			},
			["mythic"] = {
				["kills"] = 6,
				["wipes"] = 16,
				["best"] = 331.2519999999931,
			},
		},
		[2527] = {
			["heroic"] = {
				["best"] = 149.8830000000016,
				["kills"] = 5,
			},
			["mythic"] = {
				["kills"] = 5,
				["wipes"] = 22,
				["best"] = 295.7030000000013,
			},
		},
		[2520] = {
			["mythic"] = {
				["kills"] = 7,
				["wipes"] = 588,
				["best"] = 421.6270000000004,
			},
			["heroic"] = {
				["kills"] = 6,
				["best"] = 261.0840000000026,
				["wipes"] = 3,
			},
		},
	},
	[1008] = {
		[726] = {
			["10h"] = {
				["best"] = 251.66,
				["kills"] = 3,
			},
			["lfr"] = {
				["best"] = 179.523000000001,
				["kills"] = 7,
			},
		},
		[679] = {
			["lfr"] = {
				["kills"] = 8,
				["best"] = 116.476999999999,
				["wipes"] = 1,
			},
			["10h"] = {
				["best"] = 159.091999999999,
				["kills"] = 2,
			},
			["10"] = {
				["kills"] = 2,
				["best"] = 98.6489999999758,
				["wipes"] = 2,
			},
		},
		[682] = {
			["lfr"] = {
				["best"] = 147.478000000003,
				["kills"] = 5,
			},
			["10h"] = {
				["kills"] = 2,
				["wipes"] = 5,
				["best"] = 180.803,
			},
			["10"] = {
				["best"] = 215.077999999999,
				["kills"] = 1,
			},
		},
		[687] = {
			["10h"] = {
				["kills"] = 2,
				["wipes"] = 2,
				["best"] = 286.032000000007,
			},
			["lfr"] = {
				["best"] = 218.688999999999,
				["kills"] = 7,
			},
		},
		[689] = {
			["lfr"] = {
				["kills"] = 7,
				["best"] = 247.633000000002,
				["wipes"] = 1,
			},
			["10h"] = {
				["best"] = 219.030999999999,
				["kills"] = 3,
			},
			["10"] = {
				["wipes"] = 1,
			},
		},
		[677] = {
			["lfr"] = {
				["best"] = 284.988000000001,
				["kills"] = 7,
			},
			["10h"] = {
				["kills"] = 1,
				["wipes"] = 1,
				["best"] = 423.063,
			},
			["10"] = {
				["best"] = 384.17,
				["kills"] = 1,
			},
		},
	},
	[1861] = {
		[2168] = {
			["normal"] = {
				["best"] = 204.098999999987,
				["kills"] = 3,
			},
			["heroic"] = {
				["kills"] = 16,
				["wipes"] = 2,
				["best"] = 203.333999999999,
			},
			["mythic"] = {
				["kills"] = 21,
				["wipes"] = 10,
				["best"] = 222.804000000004,
			},
			["LFR"] = {
				["best"] = 263.531000000017,
				["kills"] = 3,
			},
		},
		[2169] = {
			["normal"] = {
				["best"] = 200.679999999993,
				["kills"] = 3,
			},
			["heroic"] = {
				["kills"] = 17,
				["wipes"] = 8,
				["best"] = 215.877,
			},
			["mythic"] = {
				["kills"] = 20,
				["wipes"] = 36,
				["best"] = 314.342000000001,
			},
			["LFR"] = {
				["best"] = 215.967999999994,
				["kills"] = 4,
			},
		},
		[2146] = {
			["normal"] = {
				["best"] = 74.3729999999923,
				["kills"] = 4,
			},
			["mythic"] = {
				["kills"] = 21,
				["wipes"] = 186,
				["best"] = 185.757000000001,
			},
			["heroic"] = {
				["kills"] = 18,
				["wipes"] = 1,
				["best"] = 67.107,
			},
			["LFR"] = {
				["best"] = 98.1510000000126,
				["kills"] = 1,
			},
		},
		[2167] = {
			["normal"] = {
				["best"] = 137.467000000004,
				["kills"] = 4,
			},
			["heroic"] = {
				["kills"] = 18,
				["wipes"] = 3,
				["best"] = 138.65,
			},
			["mythic"] = {
				["kills"] = 22,
				["wipes"] = 17,
				["best"] = 176.673999999999,
			},
			["LFR"] = {
				["best"] = 252.996000000014,
				["kills"] = 3,
			},
		},
		[2194] = {
			["normal"] = {
				["best"] = 245.976999999984,
				["kills"] = 3,
			},
			["heroic"] = {
				["kills"] = 19,
				["wipes"] = 17,
				["best"] = 255.314,
			},
			["mythic"] = {
				["kills"] = 21,
				["wipes"] = 247,
				["best"] = 393.142999999982,
			},
		},
		[2166] = {
			["normal"] = {
				["best"] = 157.540999999997,
				["kills"] = 3,
			},
			["heroic"] = {
				["kills"] = 17,
				["best"] = 157.232,
				["wipes"] = 1,
			},
			["mythic"] = {
				["kills"] = 23,
				["wipes"] = 43,
				["best"] = 270.421000000031,
			},
			["LFR"] = {
				["best"] = 301.497000000032,
				["kills"] = 1,
			},
		},
		[2195] = {
			["normal"] = {
				["best"] = 130.569000000018,
				["kills"] = 3,
			},
			["heroic"] = {
				["kills"] = 19,
				["wipes"] = 33,
				["best"] = 118.130000000001,
			},
			["mythic"] = {
				["kills"] = 21,
				["wipes"] = 74,
				["best"] = 190.131000000052,
			},
		},
		[2147] = {
			["heroic"] = {
				["kills"] = 17,
				["wipes"] = 57,
				["best"] = 326.226000000001,
			},
			["mythic"] = {
				["kills"] = 5,
				["wipes"] = 319,
				["best"] = 493.778999999999,
			},
			["normal"] = {
				["kills"] = 3,
				["wipes"] = 2,
				["best"] = 392.531000000001,
			},
		},
	},
	[1676] = {
		[1861] = {
			["normal"] = {
				["best"] = 155.756999999983,
				["kills"] = 4,
			},
			["mythic"] = {
				["kills"] = 13,
				["best"] = 296.968999999983,
				["wipes"] = 5,
			},
			["heroic"] = {
				["best"] = 160.20299999998,
				["kills"] = 14,
			},
			["LFR"] = {
				["kills"] = 5,
				["best"] = 174.131000000001,
				["wipes"] = 2,
			},
		},
		[1873] = {
			["normal"] = {
				["best"] = 198.77899999998,
				["kills"] = 4,
			},
			["mythic"] = {
				["kills"] = 11,
				["wipes"] = 11,
				["best"] = 330.891999999993,
			},
			["heroic"] = {
				["kills"] = 14,
				["wipes"] = 11,
				["best"] = 216.363000000012,
			},
			["LFR"] = {
				["best"] = 195.820999999996,
				["kills"] = 4,
			},
		},
		[1862] = {
			["normal"] = {
				["best"] = 93.9440000000177,
				["kills"] = 4,
			},
			["heroic"] = {
				["best"] = 98.7749999999069,
				["kills"] = 13,
			},
			["mythic"] = {
				["kills"] = 19,
				["best"] = 147.762999999977,
				["wipes"] = 5,
			},
			["LFR"] = {
				["best"] = 132.373,
				["kills"] = 5,
			},
		},
		[1896] = {
			["normal"] = {
				["best"] = 156.895000000019,
				["kills"] = 4,
			},
			["mythic"] = {
				["kills"] = 20,
				["best"] = 259.670999999973,
				["wipes"] = 9,
			},
			["heroic"] = {
				["kills"] = 13,
				["wipes"] = 3,
				["best"] = 158.695000000065,
			},
			["LFR"] = {
				["best"] = 161.495999999999,
				["kills"] = 4,
			},
		},
		[1897] = {
			["normal"] = {
				["kills"] = 4,
				["wipes"] = 1,
				["best"] = 214.863000000012,
			},
			["mythic"] = {
				["kills"] = 13,
				["best"] = 202.786000000022,
				["wipes"] = 22,
			},
			["heroic"] = {
				["kills"] = 13,
				["wipes"] = 7,
				["best"] = 172.356000000029,
			},
			["LFR"] = {
				["best"] = 187.574000000022,
				["kills"] = 4,
			},
		},
		[1856] = {
			["normal"] = {
				["best"] = 110.883000000031,
				["kills"] = 4,
			},
			["heroic"] = {
				["best"] = 104.85400000005,
				["kills"] = 14,
			},
			["mythic"] = {
				["kills"] = 20,
				["best"] = 144.988000000012,
				["wipes"] = 1,
			},
			["LFR"] = {
				["best"] = 138.181000000004,
				["kills"] = 5,
			},
		},
		[1867] = {
			["normal"] = {
				["best"] = 107.630000000005,
				["kills"] = 4,
			},
			["heroic"] = {
				["best"] = 110.381000000052,
				["kills"] = 13,
			},
			["mythic"] = {
				["best"] = 134.580000000016,
				["kills"] = 19,
			},
			["LFR"] = {
				["best"] = 153.113999999998,
				["kills"] = 4,
			},
		},
		[1898] = {
			["normal"] = {
				["best"] = 274.966000000015,
				["kills"] = 4,
			},
			["mythic"] = {
				["kills"] = 10,
				["wipes"] = 28,
				["best"] = 649.141000000003,
			},
			["heroic"] = {
				["kills"] = 12,
				["wipes"] = 26,
				["best"] = 285.008999999962,
			},
			["LFR"] = {
				["best"] = 340.494000000006,
				["kills"] = 4,
			},
		},
		[1903] = {
			["normal"] = {
				["best"] = 135.399000000034,
				["kills"] = 4,
			},
			["mythic"] = {
				["kills"] = 20,
				["best"] = 255.486000000034,
				["wipes"] = 1,
			},
			["heroic"] = {
				["best"] = 128.401000000071,
				["kills"] = 14,
			},
			["LFR"] = {
				["best"] = 178.903999999999,
				["kills"] = 4,
			},
		},
	},
	[1648] = {
		[1830] = {
			["mythic"] = {
				["kills"] = 18,
				["wipes"] = 66,
				["best"] = 97.1929999999702,
			},
			["normal"] = {
				["best"] = 19.8509999999988,
				["kills"] = 40,
			},
			["heroic"] = {
				["kills"] = 49,
				["wipes"] = 5,
				["best"] = 26.7600000000093,
			},
			["LFR"] = {
				["kills"] = 50,
				["best"] = 25.7799999999988,
				["wipes"] = 6,
			},
		},
		[1819] = {
			["mythic"] = {
				["kills"] = 17,
				["wipes"] = 8,
				["best"] = 165.864999999998,
			},
			["normal"] = {
				["kills"] = 40,
				["best"] = 40.0100000000093,
				["wipes"] = 2,
			},
			["heroic"] = {
				["kills"] = 49,
				["wipes"] = 12,
				["best"] = 72.2310000000289,
			},
			["LFR"] = {
				["kills"] = 52,
				["wipes"] = 4,
				["best"] = 58.6599999999162,
			},
		},
		[1829] = {
			["mythic"] = {
				["kills"] = 17,
				["wipes"] = 303,
				["best"] = 322.991999999969,
			},
			["heroic"] = {
				["kills"] = 48,
				["wipes"] = 44,
				["best"] = 64.3459999999032,
			},
			["normal"] = {
				["best"] = 55.6779999999562,
				["kills"] = 40,
			},
			["LFR"] = {
				["kills"] = 50,
				["best"] = 73.3840000000018,
				["wipes"] = 3,
			},
		},
	},
	[996] = {
		[683] = {
			["lfr"] = {
				["best"] = 273.206000000006,
				["kills"] = 2,
			},
			["25h"] = {
				["best"] = 398.580000000016,
				["kills"] = 1,
			},
			["10"] = {
				["best"] = 390.364,
				["kills"] = 1,
			},
		},
		[742] = {
			["lfr"] = {
				["kills"] = 6,
				["best"] = 261.015999999996,
				["wipes"] = 1,
			},
			["25h"] = {
				["best"] = 381.780000000028,
				["kills"] = 1,
			},
			["10"] = {
				["best"] = 352.665000000001,
				["kills"] = 1,
			},
		},
		[729] = {
			["lfr"] = {
				["best"] = 283.603999999999,
				["kills"] = 6,
			},
			["25h"] = {
				["kills"] = 1,
				["wipes"] = 3,
				["best"] = 314.958999999974,
			},
			["10"] = {
				["best"] = 357.722,
				["kills"] = 1,
			},
		},
		[709] = {
			["25"] = {
				["best"] = 416.739999999998,
				["kills"] = 1,
			},
			["lfr"] = {
				["best"] = 216.228999999999,
				["kills"] = 6,
			},
			["25h"] = {
				["kills"] = 1,
				["wipes"] = 1,
				["best"] = 863.268999999971,
			},
			["10"] = {
				["best"] = 568.272000000001,
				["kills"] = 1,
			},
		},
	},
	[2217] = {
		[2364] = {
			["heroic"] = {
				["kills"] = 11,
				["best"] = 147.6109999999972,
				["wipes"] = 9,
			},
			["mythic"] = {
				["kills"] = 19,
				["wipes"] = 104,
				["best"] = 171.2360000000335,
			},
		},
		[2372] = {
			["heroic"] = {
				["kills"] = 10,
				["best"] = 111.1620000000003,
				["wipes"] = 2,
			},
			["mythic"] = {
				["kills"] = 16,
				["wipes"] = 11,
				["best"] = 140.9180000000051,
			},
		},
		[2365] = {
			["heroic"] = {
				["kills"] = 12,
				["wipes"] = 2,
				["best"] = 98.58000000000175,
			},
			["mythic"] = {
				["kills"] = 20,
				["wipes"] = 10,
				["best"] = 111.3909999999451,
			},
		},
		[2373] = {
			["mythic"] = {
				["kills"] = 17,
				["wipes"] = 47,
				["best"] = 263.9790000000503,
			},
			["heroic"] = {
				["best"] = 170.7119999999995,
				["kills"] = 10,
			},
			["LFR"] = {
				["best"] = 204.9020000000019,
				["kills"] = 1,
			},
		},
		[2366] = {
			["normal"] = {
				["best"] = 504.3369999999995,
				["kills"] = 1,
			},
			["mythic"] = {
				["kills"] = 18,
				["wipes"] = 60,
				["best"] = 339.8410000000149,
			},
			["heroic"] = {
				["kills"] = 10,
				["wipes"] = 8,
				["best"] = 313.7759999999998,
			},
			["LFR"] = {
				["best"] = 491.8249999999825,
				["kills"] = 1,
			},
		},
		[2374] = {
			["mythic"] = {
				["kills"] = 13,
				["wipes"] = 85,
				["best"] = 381.1320000000997,
			},
			["heroic"] = {
				["kills"] = 10,
				["best"] = 213.4750000000004,
				["wipes"] = 8,
			},
			["LFR"] = {
				["best"] = 368.586000000003,
				["kills"] = 1,
			},
		},
		[2367] = {
			["mythic"] = {
				["kills"] = 16,
				["wipes"] = 15,
				["best"] = 151.7710000000006,
			},
			["heroic"] = {
				["best"] = 149.5339999999997,
				["kills"] = 10,
			},
			["LFR"] = {
				["best"] = 141.8660000000018,
				["kills"] = 1,
			},
		},
		[2375] = {
			["mythic"] = {
				["kills"] = 14,
				["wipes"] = 267,
				["best"] = 623.6720000000205,
			},
			["heroic"] = {
				["kills"] = 10,
				["wipes"] = 10,
				["best"] = 476.1609999999637,
			},
			["LFR"] = {
				["kills"] = 1,
				["wipes"] = 2,
				["best"] = 605.4389999999839,
			},
		},
		[2368] = {
			["heroic"] = {
				["kills"] = 23,
				["wipes"] = 1,
				["best"] = 105.8880000000008,
			},
			["mythic"] = {
				["kills"] = 20,
				["wipes"] = 3,
				["best"] = 207.0439999999944,
			},
		},
		[2369] = {
			["heroic"] = {
				["best"] = 144.2139999999999,
				["kills"] = 14,
			},
			["mythic"] = {
				["kills"] = 20,
				["wipes"] = 3,
				["best"] = 127.1169999999693,
			},
		},
		[2377] = {
			["heroic"] = {
				["kills"] = 11,
				["best"] = 173.7390000000014,
				["wipes"] = 2,
			},
			["mythic"] = {
				["kills"] = 17,
				["wipes"] = 68,
				["best"] = 184.0020000000004,
			},
		},
		[2370] = {
			["heroic"] = {
				["kills"] = 11,
				["best"] = 136.4639999999999,
				["wipes"] = 4,
			},
			["mythic"] = {
				["kills"] = 14,
				["wipes"] = 16,
				["best"] = 208.6779999999562,
			},
		},
	},
	[1712] = {
		[1992] = {
			["heroic"] = {
				["kills"] = 35,
				["best"] = 113.044000000001,
				["wipes"] = 4,
			},
			["mythic"] = {
				["kills"] = 36,
				["wipes"] = 15,
				["best"] = 164.854,
			},
			["normal"] = {
				["kills"] = 4,
				["best"] = 146.655999999999,
				["wipes"] = 1,
			},
			["LFR"] = {
				["best"] = 190.41,
				["kills"] = 2,
			},
		},
		[1985] = {
			["normal"] = {
				["best"] = 208.371999999999,
				["kills"] = 3,
			},
			["heroic"] = {
				["kills"] = 36,
				["best"] = 195.036,
				["wipes"] = 3,
			},
			["mythic"] = {
				["kills"] = 29,
				["wipes"] = 28,
				["best"] = 265.632999999973,
			},
		},
		[2004] = {
			["normal"] = {
				["kills"] = 4,
				["best"] = 237.621999999974,
				["wipes"] = 1,
			},
			["heroic"] = {
				["kills"] = 40,
				["best"] = 202.754000000001,
				["wipes"] = 6,
			},
			["mythic"] = {
				["kills"] = 28,
				["best"] = 359.902000000002,
				["wipes"] = 10,
			},
		},
		[1997] = {
			["heroic"] = {
				["kills"] = 37,
				["best"] = 166.557999999999,
				["wipes"] = 8,
			},
			["mythic"] = {
				["kills"] = 32,
				["wipes"] = 21,
				["best"] = 244.983999999997,
			},
			["normal"] = {
				["best"] = 201.575000000001,
				["kills"] = 4,
			},
			["LFR"] = {
				["best"] = 238.709000000001,
				["kills"] = 4,
			},
		},
		[1986] = {
			["normal"] = {
				["best"] = 220.615,
				["kills"] = 6,
			},
			["heroic"] = {
				["kills"] = 41,
				["best"] = 169.511999999999,
				["wipes"] = 11,
			},
			["mythic"] = {
				["kills"] = 26,
				["wipes"] = 25,
				["best"] = 321.356,
			},
		},
		[2009] = {
			["normal"] = {
				["best"] = 172.754999999999,
				["kills"] = 6,
			},
			["heroic"] = {
				["kills"] = 40,
				["best"] = 149.894,
				["wipes"] = 5,
			},
			["mythic"] = {
				["kills"] = 26,
				["wipes"] = 35,
				["best"] = 330.407000000007,
			},
		},
		[1983] = {
			["normal"] = {
				["best"] = 152.513000000035,
				["kills"] = 4,
			},
			["heroic"] = {
				["kills"] = 40,
				["best"] = 122.975,
				["wipes"] = 22,
			},
			["mythic"] = {
				["kills"] = 28,
				["wipes"] = 87,
				["best"] = 188.355,
			},
		},
		[1987] = {
			["heroic"] = {
				["kills"] = 36,
				["best"] = 111.340999999999,
				["wipes"] = 8,
			},
			["mythic"] = {
				["kills"] = 31,
				["wipes"] = 12,
				["best"] = 147.549999999988,
			},
			["normal"] = {
				["best"] = 116.311000000002,
				["kills"] = 4,
			},
			["LFR"] = {
				["best"] = 162.673999999999,
				["kills"] = 2,
			},
		},
		[2025] = {
			["normal"] = {
				["best"] = 0.069999999999709,
				["kills"] = 4,
			},
			["mythic"] = {
				["kills"] = 23,
				["best"] = 454.938999999999,
				["wipes"] = 6,
			},
			["heroic"] = {
				["best"] = 0.080999999998312,
				["kills"] = 23,
			},
		},
		[1984] = {
			["normal"] = {
				["kills"] = 3,
				["wipes"] = 4,
				["best"] = 242.281999999999,
			},
			["heroic"] = {
				["kills"] = 37,
				["wipes"] = 56,
				["best"] = 208.01,
			},
			["mythic"] = {
				["kills"] = 21,
				["wipes"] = 131,
				["best"] = 339.964,
			},
			["LFR"] = {
				["kills"] = 3,
				["wipes"] = 2,
				["best"] = 201.258999999991,
			},
		},
		[2031] = {
			["normal"] = {
				["kills"] = 10,
				["best"] = 343.337,
				["wipes"] = 1,
			},
			["mythic"] = {
				["kills"] = 17,
				["wipes"] = 81,
				["best"] = 503.257000000001,
			},
			["heroic"] = {
				["kills"] = 63,
				["best"] = 339.087,
				["wipes"] = 15,
			},
			["LFR"] = {
				["best"] = 503.585000000021,
				["kills"] = 3,
			},
		},
	},
	[1530] = {
		[1737] = {
			["normal"] = {
				["kills"] = 37,
				["best"] = 135.255000000001,
				["wipes"] = 1,
			},
			["heroic"] = {
				["kills"] = 44,
				["wipes"] = 22,
				["best"] = 152.873000000021,
			},
			["mythic"] = {
				["kills"] = 16,
				["wipes"] = 384,
				["best"] = 609.381999999998,
			},
			["LFR"] = {
				["best"] = 176.900000000001,
				["kills"] = 33,
			},
		},
		[1761] = {
			["normal"] = {
				["best"] = 54.4780000000028,
				["kills"] = 35,
			},
			["heroic"] = {
				["kills"] = 41,
				["wipes"] = 14,
				["best"] = 64.9600000000792,
			},
			["mythic"] = {
				["kills"] = 17,
				["wipes"] = 18,
				["best"] = 299.690000000002,
			},
			["LFR"] = {
				["kills"] = 43,
				["best"] = 82.091999999946,
				["wipes"] = 1,
			},
		},
		[1732] = {
			["normal"] = {
				["kills"] = 35,
				["best"] = 59.3950000000186,
				["wipes"] = 1,
			},
			["mythic"] = {
				["kills"] = 19,
				["wipes"] = 139,
				["best"] = 201.466999999997,
			},
			["heroic"] = {
				["kills"] = 42,
				["best"] = 78.6319999999832,
				["wipes"] = 1,
			},
			["LFR"] = {
				["best"] = 94.9749999999767,
				["kills"] = 43,
			},
		},
		[1713] = {
			["normal"] = {
				["best"] = 32.5560000000005,
				["kills"] = 36,
			},
			["mythic"] = {
				["kills"] = 19,
				["wipes"] = 11,
				["best"] = 175.165000000008,
			},
			["heroic"] = {
				["kills"] = 40,
				["best"] = 46.5740000000224,
				["wipes"] = 2,
			},
			["LFR"] = {
				["best"] = 43.2459999999992,
				["kills"] = 36,
			},
		},
		[1762] = {
			["normal"] = {
				["kills"] = 35,
				["best"] = 57.0359999999637,
				["wipes"] = 1,
			},
			["mythic"] = {
				["kills"] = 17,
				["wipes"] = 22,
				["best"] = 208.041999999998,
			},
			["heroic"] = {
				["kills"] = 40,
				["best"] = 63.1940000000177,
				["wipes"] = 8,
			},
			["LFR"] = {
				["kills"] = 36,
				["best"] = 57.1570000000065,
				["wipes"] = 1,
			},
		},
		[1706] = {
			["normal"] = {
				["best"] = 26.1279999999097,
				["kills"] = 37,
			},
			["mythic"] = {
				["best"] = 68.7139999999999,
				["kills"] = 17,
			},
			["heroic"] = {
				["kills"] = 40,
				["wipes"] = 1,
				["best"] = 37.7069999999367,
			},
			["LFR"] = {
				["best"] = 25.4280000000726,
				["kills"] = 45,
			},
		},
		[1725] = {
			["normal"] = {
				["best"] = 28.005000000001,
				["kills"] = 36,
			},
			["mythic"] = {
				["kills"] = 18,
				["best"] = 71.2459999999992,
				["wipes"] = 1,
			},
			["heroic"] = {
				["kills"] = 41,
				["best"] = 33.112000000081,
				["wipes"] = 3,
			},
			["LFR"] = {
				["best"] = 32.7160000000004,
				["kills"] = 44,
			},
		},
		[1731] = {
			["normal"] = {
				["best"] = 37.3889999999665,
				["kills"] = 36,
			},
			["mythic"] = {
				["kills"] = 19,
				["best"] = 95.8820000000014,
				["wipes"] = 1,
			},
			["heroic"] = {
				["kills"] = 42,
				["best"] = 51.9279999999562,
				["wipes"] = 1,
			},
			["LFR"] = {
				["best"] = 43.4479999999894,
				["kills"] = 44,
			},
		},
		[1751] = {
			["normal"] = {
				["kills"] = 35,
				["best"] = 42.7590000000782,
				["wipes"] = 1,
			},
			["heroic"] = {
				["kills"] = 40,
				["best"] = 60.4640000000363,
				["wipes"] = 4,
			},
			["mythic"] = {
				["kills"] = 17,
				["wipes"] = 28,
				["best"] = 143.800999999999,
			},
			["LFR"] = {
				["kills"] = 43,
				["best"] = 61.464,
				["wipes"] = 1,
			},
		},
		[1743] = {
			["normal"] = {
				["kills"] = 37,
				["best"] = 87.9239999999991,
				["wipes"] = 3,
			},
			["heroic"] = {
				["kills"] = 45,
				["wipes"] = 10,
				["best"] = 102.976000000024,
			},
			["mythic"] = {
				["kills"] = 25,
				["wipes"] = 88,
				["best"] = 154.167000000016,
			},
			["LFR"] = {
				["best"] = 108.596999999951,
				["kills"] = 36,
			},
		},
	},
	[1520] = {
		[1744] = {
			["normal"] = {
				["best"] = 23.5219999999972,
				["kills"] = 42,
			},
			["mythic"] = {
				["kills"] = 18,
				["wipes"] = 7,
				["best"] = 91.2229999999982,
			},
			["heroic"] = {
				["kills"] = 54,
				["wipes"] = 11,
				["best"] = 24.2210000000196,
			},
			["LFR"] = {
				["kills"] = 55,
				["best"] = 23.9230000000025,
				["wipes"] = 1,
			},
		},
		[1738] = {
			["normal"] = {
				["best"] = 96.8009999999777,
				["kills"] = 42,
			},
			["mythic"] = {
				["kills"] = 18,
				["wipes"] = 33,
				["best"] = 222.101999999999,
			},
			["heroic"] = {
				["kills"] = 54,
				["wipes"] = 2,
				["best"] = 94.872999999905,
			},
			["LFR"] = {
				["kills"] = 55,
				["best"] = 82.6700000000019,
				["wipes"] = 2,
			},
		},
		[1667] = {
			["normal"] = {
				["best"] = 15.9020000000019,
				["kills"] = 42,
			},
			["heroic"] = {
				["best"] = 18.4600000000792,
				["kills"] = 52,
			},
			["mythic"] = {
				["kills"] = 18,
				["wipes"] = 4,
				["best"] = 64.7890000000043,
			},
			["LFR"] = {
				["best"] = 18.849000000002,
				["kills"] = 61,
			},
		},
		[1704] = {
			["normal"] = {
				["kills"] = 42,
				["best"] = 17.4030000000494,
				["wipes"] = 1,
			},
			["mythic"] = {
				["kills"] = 17,
				["wipes"] = 6,
				["best"] = 41.5950000000012,
			},
			["heroic"] = {
				["kills"] = 52,
				["best"] = 19.3220000000438,
				["wipes"] = 1,
			},
			["LFR"] = {
				["best"] = 20.4049999999988,
				["kills"] = 61,
			},
		},
		[1750] = {
			["normal"] = {
				["best"] = 15.6300000000047,
				["kills"] = 42,
			},
			["heroic"] = {
				["kills"] = 55,
				["wipes"] = 13,
				["best"] = 19.2610000000568,
			},
			["mythic"] = {
				["kills"] = 17,
				["wipes"] = 106,
				["best"] = 63.4150000000009,
			},
			["LFR"] = {
				["kills"] = 61,
				["best"] = 15.3899999999994,
				["wipes"] = 1,
			},
		},
		[1726] = {
			["normal"] = {
				["best"] = 25.8709999999992,
				["kills"] = 42,
			},
			["mythic"] = {
				["kills"] = 17,
				["wipes"] = 18,
				["best"] = 118.486000000004,
			},
			["heroic"] = {
				["kills"] = 55,
				["wipes"] = 13,
				["best"] = 29.545999999973,
			},
			["LFR"] = {
				["best"] = 31.4490000000224,
				["kills"] = 55,
			},
		},
		[1703] = {
			["normal"] = {
				["best"] = 22.3140000000021,
				["kills"] = 42,
			},
			["mythic"] = {
				["kills"] = 19,
				["best"] = 71.7380000000048,
				["wipes"] = 1,
			},
			["heroic"] = {
				["kills"] = 53,
				["best"] = 24.0979999999981,
				["wipes"] = 1,
			},
			["LFR"] = {
				["best"] = 21.2620000000024,
				["kills"] = 58,
			},
		},
	},
	[2070] = {
		[2341] = {
			["heroic"] = {
				["best"] = 184.092999999994,
				["kills"] = 6,
			},
			["mythic"] = {
				["kills"] = 27,
				["wipes"] = 7,
				["best"] = 195.6599999999162,
			},
		},
		[2334] = {
			["heroic"] = {
				["kills"] = 5,
				["wipes"] = 2,
				["best"] = 290.572,
			},
			["mythic"] = {
				["kills"] = 18,
				["wipes"] = 14,
				["best"] = 192.6260000000002,
			},
		},
		[2342] = {
			["heroic"] = {
				["kills"] = 7,
				["wipes"] = 11,
				["best"] = 305.951000000001,
			},
			["mythic"] = {
				["kills"] = 26,
				["wipes"] = 15,
				["best"] = 367.6009999999078,
			},
		},
		[2335] = {
			["heroic"] = {
				["kills"] = 10,
				["wipes"] = 1,
				["best"] = 279.122000000003,
			},
			["mythic"] = {
				["kills"] = 26,
				["wipes"] = 8,
				["best"] = 71.8360000001267,
			},
		},
		[2343] = {
			["heroic"] = {
				["kills"] = 5,
				["wipes"] = 11,
				["best"] = 411.656999999992,
			},
			["mythic"] = {
				["kills"] = 8,
				["wipes"] = 31,
				["best"] = 212.9239999999991,
			},
		},
		[2337] = {
			["heroic"] = {
				["kills"] = 7,
				["wipes"] = 3,
				["best"] = 258.357000000004,
			},
			["mythic"] = {
				["kills"] = 11,
				["wipes"] = 14,
				["best"] = 108.0679999999993,
			},
		},
		[2330] = {
			["heroic"] = {
				["kills"] = 7,
				["wipes"] = 5,
				["best"] = 201.405000000028,
			},
			["mythic"] = {
				["kills"] = 25,
				["best"] = 204.8619999999646,
				["wipes"] = 4,
			},
		},
		[2325] = {
			["heroic"] = {
				["kills"] = 5,
				["best"] = 148.383000000002,
				["wipes"] = 3,
			},
			["mythic"] = {
				["kills"] = 26,
				["best"] = 209.2330000000075,
				["wipes"] = 11,
			},
		},
		[2333] = {
			["heroic"] = {
				["kills"] = 7,
				["best"] = 71.6520000000019,
				["wipes"] = 1,
			},
			["mythic"] = {
				["kills"] = 28,
				["wipes"] = 1,
				["best"] = 64.9749999998603,
			},
		},
	},
	[2549] = {
		[2553] = {
			["normal"] = {
				["best"] = 188.9409999999989,
				["kills"] = 3,
			},
			["heroic"] = {
				["kills"] = 5,
				["wipes"] = 5,
				["best"] = 225.3269999999902,
			},
			["LFR"] = {
				["kills"] = 2,
				["best"] = 229.469000000001,
				["wipes"] = 1,
			},
		},
		[2554] = {
			["normal"] = {
				["best"] = 137.2109999999993,
				["kills"] = 4,
			},
			["mythic"] = {
				["kills"] = 1,
				["wipes"] = 1,
				["best"] = 330.5580000000009,
			},
			["heroic"] = {
				["kills"] = 5,
				["best"] = 168.6949999999997,
				["wipes"] = 1,
			},
			["LFR"] = {
				["best"] = 151.2719999999999,
				["kills"] = 3,
			},
		},
		[2555] = {
			["normal"] = {
				["best"] = 153.760000000002,
				["kills"] = 3,
			},
			["mythic"] = {
				["kills"] = 1,
				["wipes"] = 8,
				["best"] = 432.0980000000018,
			},
			["heroic"] = {
				["best"] = 182.0699999999997,
				["kills"] = 3,
			},
			["LFR"] = {
				["best"] = 172.2839999999997,
				["kills"] = 3,
			},
		},
		[2563] = {
			["normal"] = {
				["best"] = 105.9939999999988,
				["kills"] = 4,
			},
			["mythic"] = {
				["wipes"] = 24,
			},
			["heroic"] = {
				["kills"] = 4,
				["best"] = 258.0959999999614,
				["wipes"] = 3,
			},
			["LFR"] = {
				["best"] = 141.3239999999996,
				["kills"] = 3,
			},
		},
		[2556] = {
			["normal"] = {
				["best"] = 137.3740000000034,
				["kills"] = 3,
			},
			["mythic"] = {
				["wipes"] = 5,
			},
			["heroic"] = {
				["best"] = 174.3450000000012,
				["kills"] = 3,
			},
			["LFR"] = {
				["kills"] = 3,
				["best"] = 154.9890000000014,
				["wipes"] = 1,
			},
		},
		[2564] = {
			["normal"] = {
				["best"] = 87.1239999999998,
				["kills"] = 4,
			},
			["heroic"] = {
				["best"] = 138.4089999999997,
				["kills"] = 5,
			},
			["LFR"] = {
				["best"] = 159.8200000000034,
				["kills"] = 2,
			},
		},
		[2557] = {
			["normal"] = {
				["kills"] = 3,
				["best"] = 122.9799999999814,
				["wipes"] = 2,
			},
			["mythic"] = {
				["kills"] = 1,
				["wipes"] = 1,
				["best"] = 248.5689999999995,
			},
			["heroic"] = {
				["kills"] = 6,
				["wipes"] = 2,
				["best"] = 133.0239999999994,
			},
			["LFR"] = {
				["best"] = 141.9740000000002,
				["kills"] = 3,
			},
		},
		[2565] = {
			["normal"] = {
				["kills"] = 4,
				["best"] = 191.2890000000007,
				["wipes"] = 1,
			},
			["heroic"] = {
				["kills"] = 3,
				["wipes"] = 4,
				["best"] = 346.3709999999992,
			},
			["LFR"] = {
				["best"] = 391.5129999999999,
				["kills"] = 2,
			},
		},
		[2519] = {
			["normal"] = {
				["best"] = 271.6650000000009,
				["kills"] = 4,
			},
			["heroic"] = {
				["kills"] = 4,
				["wipes"] = 7,
				["best"] = 398.8489999999983,
			},
			["LFR"] = {
				["best"] = 352.3270000000002,
				["kills"] = 2,
			},
		},
	},
	[1098] = {
		[818] = {
			["25"] = {
				["wipes"] = 4,
			},
			["25h"] = {
				["kills"] = 8,
				["wipes"] = 25,
				["best"] = 182.523000000001,
			},
			["10h"] = {
				["kills"] = 16,
				["best"] = 86.8479999999982,
				["wipes"] = 3,
			},
			["lfr"] = {
				["kills"] = 17,
				["best"] = 93.1330000000016,
				["wipes"] = 4,
			},
			["10"] = {
				["kills"] = 7,
				["wipes"] = 2,
				["best"] = 236.918000000005,
			},
		},
		[820] = {
			["25"] = {
				["best"] = 308.125999999989,
				["kills"] = 2,
			},
			["25h"] = {
				["kills"] = 7,
				["wipes"] = 38,
				["best"] = 244.179000000004,
			},
			["10h"] = {
				["kills"] = 16,
				["best"] = 132.266999999993,
				["wipes"] = 1,
			},
			["lfr"] = {
				["kills"] = 18,
				["best"] = 115.622000000001,
				["wipes"] = 1,
			},
			["10"] = {
				["kills"] = 6,
				["wipes"] = 1,
				["best"] = 107.260000000002,
			},
		},
		[824] = {
			["25"] = {
				["best"] = 194.599000000002,
				["kills"] = 3,
			},
			["25h"] = {
				["kills"] = 10,
				["wipes"] = 157,
				["best"] = 124.588999999978,
			},
			["10h"] = {
				["kills"] = 15,
				["wipes"] = 14,
				["best"] = 76.9850000000006,
			},
			["lfr"] = {
				["kills"] = 15,
				["best"] = 172.900000000023,
				["wipes"] = 2,
			},
			["10"] = {
				["kills"] = 10,
				["wipes"] = 16,
				["best"] = 56.5249999999651,
			},
		},
		[828] = {
			["25"] = {
				["kills"] = 2,
				["wipes"] = 2,
				["best"] = 329.132000000001,
			},
			["25h"] = {
				["kills"] = 10,
				["wipes"] = 41,
				["best"] = 120.830000000002,
			},
			["10h"] = {
				["kills"] = 19,
				["wipes"] = 17,
				["best"] = 57.4059999999954,
			},
			["lfr"] = {
				["kills"] = 17,
				["best"] = 61.0019999999786,
				["wipes"] = 3,
			},
			["10"] = {
				["kills"] = 3,
				["wipes"] = 4,
				["best"] = 61.9130000000005,
			},
		},
		[817] = {
			["25"] = {
				["kills"] = 3,
				["wipes"] = 6,
				["best"] = 572.418999999994,
			},
			["25h"] = {
				["kills"] = 11,
				["wipes"] = 24,
				["best"] = 270.944000000018,
			},
			["10h"] = {
				["kills"] = 17,
				["wipes"] = 31,
				["best"] = 133.375,
			},
			["lfr"] = {
				["kills"] = 14,
				["best"] = 155.837999999989,
				["wipes"] = 1,
			},
			["10"] = {
				["kills"] = 8,
				["best"] = 151.97100000002,
				["wipes"] = 1,
			},
		},
		[819] = {
			["25"] = {
				["best"] = 530.195999999996,
				["kills"] = 1,
			},
			["25h"] = {
				["kills"] = 11,
				["wipes"] = 10,
				["best"] = 269.400000000002,
			},
			["10h"] = {
				["kills"] = 19,
				["wipes"] = 38,
				["best"] = 155.232,
			},
			["lfr"] = {
				["kills"] = 24,
				["best"] = 149.994000000064,
				["wipes"] = 8,
			},
			["10"] = {
				["kills"] = 6,
				["best"] = 127.902999999998,
				["wipes"] = 1,
			},
		},
		[821] = {
			["25"] = {
				["kills"] = 4,
				["best"] = 391.899999999994,
				["wipes"] = 1,
			},
			["25h"] = {
				["kills"] = 9,
				["wipes"] = 26,
				["best"] = 221.296000000002,
			},
			["10h"] = {
				["kills"] = 16,
				["wipes"] = 5,
				["best"] = 206.633000000002,
			},
			["lfr"] = {
				["best"] = 216.308000000019,
				["kills"] = 19,
			},
			["10"] = {
				["kills"] = 8,
				["wipes"] = 8,
				["best"] = 211.402999999998,
			},
		},
		[816] = {
			["25"] = {
				["best"] = 333.796999999999,
				["kills"] = 3,
			},
			["25h"] = {
				["kills"] = 8,
				["best"] = 170.779999999999,
				["wipes"] = 2,
			},
			["10h"] = {
				["best"] = 61.1689999999944,
				["kills"] = 17,
			},
			["lfr"] = {
				["kills"] = 21,
				["best"] = 98.2710000000661,
				["wipes"] = 2,
			},
			["10"] = {
				["best"] = 54.7569999999978,
				["kills"] = 8,
			},
		},
		[825] = {
			["25"] = {
				["kills"] = 1,
				["wipes"] = 1,
				["best"] = 315.287000000011,
			},
			["25h"] = {
				["kills"] = 9,
				["wipes"] = 17,
				["best"] = 148.364000000001,
			},
			["10h"] = {
				["kills"] = 17,
				["best"] = 61.2020000000011,
				["wipes"] = 4,
			},
			["lfr"] = {
				["kills"] = 22,
				["best"] = 70.6670000000158,
				["wipes"] = 1,
			},
			["10"] = {
				["best"] = 34.6480000000011,
				["kills"] = 8,
			},
		},
		[827] = {
			["25"] = {
				["kills"] = 2,
				["wipes"] = 1,
				["best"] = 175.064,
			},
			["25h"] = {
				["kills"] = 10,
				["wipes"] = 18,
				["best"] = 124.317000000003,
			},
			["10h"] = {
				["kills"] = 21,
				["wipes"] = 22,
				["best"] = 57.8970000000008,
			},
			["lfr"] = {
				["kills"] = 24,
				["best"] = 80.9279999999999,
				["wipes"] = 2,
			},
			["10"] = {
				["best"] = 69.1759999999995,
				["kills"] = 3,
			},
		},
		[829] = {
			["25"] = {
				["kills"] = 2,
				["wipes"] = 1,
				["best"] = 544.145999999993,
			},
			["25h"] = {
				["kills"] = 8,
				["wipes"] = 78,
				["best"] = 270.331000000006,
			},
			["10h"] = {
				["kills"] = 15,
				["wipes"] = 8,
				["best"] = 179.747000000003,
			},
			["lfr"] = {
				["best"] = 220.941999999981,
				["kills"] = 13,
			},
			["10"] = {
				["kills"] = 7,
				["wipes"] = 2,
				["best"] = 142.53899999999,
			},
		},
		[831] = {
			["10h"] = {
				["kills"] = 15,
				["best"] = 114.709999999999,
				["wipes"] = 5,
			},
			["25h"] = {
				["kills"] = 3,
				["wipes"] = 13,
				["best"] = 172.862000000001,
			},
		},
		[832] = {
			["25"] = {
				["kills"] = 5,
				["wipes"] = 8,
				["best"] = 405.503000000012,
			},
			["25h"] = {
				["kills"] = 3,
				["wipes"] = 536,
				["best"] = 432.629000000001,
			},
			["10h"] = {
				["kills"] = 11,
				["wipes"] = 13,
				["best"] = 264.059999999998,
			},
			["lfr"] = {
				["kills"] = 13,
				["wipes"] = 8,
				["best"] = 252.132999999973,
			},
			["10"] = {
				["kills"] = 3,
				["wipes"] = 13,
				["best"] = 214.921999999962,
			},
		},
	},
	[2450] = {
		[2446] = {
			["normal"] = {
				["best"] = 291.4929999999877,
				["kills"] = 2,
			},
			["heroic"] = {
				["kills"] = 12,
				["best"] = 216.5950000000012,
				["wipes"] = 7,
			},
			["mythic"] = {
				["kills"] = 35,
				["wipes"] = 15,
				["best"] = 221.1729999999516,
			},
		},
		[2439] = {
			["normal"] = {
				["best"] = 289.775999999998,
				["kills"] = 2,
			},
			["mythic"] = {
				["kills"] = 39,
				["best"] = 227.9499999997206,
				["wipes"] = 7,
			},
			["heroic"] = {
				["kills"] = 12,
				["best"] = 228.719000000041,
				["wipes"] = 1,
			},
		},
		[2447] = {
			["normal"] = {
				["kills"] = 2,
				["best"] = 501.7130000000034,
				["wipes"] = 1,
			},
			["heroic"] = {
				["kills"] = 12,
				["best"] = 377.1760000000068,
				["wipes"] = 8,
			},
			["mythic"] = {
				["kills"] = 36,
				["wipes"] = 26,
				["best"] = 299.6589999999851,
			},
		},
		[2440] = {
			["normal"] = {
				["best"] = 472.7439999999988,
				["kills"] = 2,
			},
			["heroic"] = {
				["kills"] = 12,
				["wipes"] = 7,
				["best"] = 338.5289999999804,
			},
			["mythic"] = {
				["kills"] = 53,
				["wipes"] = 26,
				["best"] = 240.8649999999907,
			},
		},
		[2441] = {
			["normal"] = {
				["kills"] = 2,
				["best"] = 905.9160000000047,
				["wipes"] = 1,
			},
			["heroic"] = {
				["kills"] = 8,
				["wipes"] = 15,
				["best"] = 701.0720000000001,
			},
			["mythic"] = {
				["kills"] = 51,
				["wipes"] = 38,
				["best"] = 548.2289999999921,
			},
		},
		[2442] = {
			["normal"] = {
				["best"] = 261.6059999999998,
				["kills"] = 2,
			},
			["mythic"] = {
				["kills"] = 39,
				["wipes"] = 18,
				["best"] = 256.4799999999814,
			},
			["heroic"] = {
				["best"] = 214.3520000000135,
				["kills"] = 12,
			},
		},
		[2435] = {
			["normal"] = {
				["best"] = 258.3159999999916,
				["kills"] = 2,
			},
			["mythic"] = {
				["kills"] = 56,
				["best"] = 154.2289999999921,
				["wipes"] = 4,
			},
			["heroic"] = {
				["best"] = 194.0650000000023,
				["kills"] = 12,
			},
		},
		[2443] = {
			["normal"] = {
				["kills"] = 2,
				["wipes"] = 2,
				["best"] = 414.4030000000057,
			},
			["heroic"] = {
				["kills"] = 12,
				["best"] = 276.280999999959,
				["wipes"] = 1,
			},
			["mythic"] = {
				["kills"] = 36,
				["best"] = 320.2930000000633,
				["wipes"] = 20,
			},
		},
		[2444] = {
			["normal"] = {
				["best"] = 244.0479999999952,
				["kills"] = 2,
			},
			["mythic"] = {
				["kills"] = 38,
				["wipes"] = 10,
				["best"] = 196.2249999999767,
			},
			["heroic"] = {
				["kills"] = 12,
				["best"] = 187.4340000000084,
				["wipes"] = 2,
			},
		},
		[2445] = {
			["normal"] = {
				["best"] = 272.833999999988,
				["kills"] = 2,
			},
			["heroic"] = {
				["kills"] = 12,
				["best"] = 223.9940000000643,
				["wipes"] = 1,
			},
			["mythic"] = {
				["kills"] = 38,
				["best"] = 286.061999999918,
				["wipes"] = 3,
			},
		},
	},
	[2481] = {
		[2461] = {
			["heroic"] = {
				["kills"] = 4,
				["wipes"] = 3,
				["best"] = 368.2619999999879,
			},
			["mythic"] = {
				["kills"] = 8,
				["wipes"] = 9,
				["best"] = 378.920999999973,
			},
		},
		[2469] = {
			["heroic"] = {
				["kills"] = 2,
				["wipes"] = 45,
				["best"] = 284.4290000000037,
			},
			["mythic"] = {
				["kills"] = 10,
				["wipes"] = 33,
				["best"] = 262.8030000000144,
			},
		},
		[2470] = {
			["heroic"] = {
				["kills"] = 4,
				["best"] = 336.9759999999078,
				["wipes"] = 2,
			},
			["mythic"] = {
				["kills"] = 7,
				["wipes"] = 2,
				["best"] = 313.8479999999981,
			},
		},
		[2463] = {
			["heroic"] = {
				["kills"] = 5,
				["wipes"] = 4,
				["best"] = 379.7939999999944,
			},
			["mythic"] = {
				["kills"] = 6,
				["best"] = 310.5630000000092,
				["wipes"] = 7,
			},
		},
		[2464] = {
			["heroic"] = {
				["best"] = 365.9859999999171,
				["kills"] = 2,
			},
			["mythic"] = {
				["kills"] = 6,
				["wipes"] = 27,
				["best"] = 248.5519999999997,
			},
			["LFR"] = {
			},
		},
		[2457] = {
			["mythic"] = {
				["kills"] = 10,
				["best"] = 156.2190000000001,
				["wipes"] = 2,
			},
			["heroic"] = {
				["kills"] = 3,
				["wipes"] = 2,
				["best"] = 251.954000000027,
			},
		},
		[2465] = {
			["heroic"] = {
				["best"] = 257.3939999999711,
				["kills"] = 4,
			},
			["mythic"] = {
				["kills"] = 8,
				["best"] = 225.226999999999,
				["wipes"] = 1,
			},
		},
		[2458] = {
			["heroic"] = {
				["best"] = 321.7029999999795,
				["kills"] = 5,
			},
			["mythic"] = {
				["best"] = 182.4369999999999,
				["kills"] = 9,
			},
		},
		[2459] = {
			["heroic"] = {
				["kills"] = 4,
				["best"] = 218.2129999999888,
				["wipes"] = 1,
			},
			["mythic"] = {
				["kills"] = 8,
				["best"] = 289.2619999999879,
				["wipes"] = 1,
			},
		},
		[2467] = {
			["mythic"] = {
				["kills"] = 8,
				["wipes"] = 35,
				["best"] = 206.8249999999998,
			},
			["heroic"] = {
				["kills"] = 3,
				["wipes"] = 7,
				["best"] = 174.1160000000382,
			},
		},
		[2460] = {
			["heroic"] = {
				["kills"] = 4,
				["best"] = 354.2179999999935,
				["wipes"] = 2,
			},
			["mythic"] = {
				["kills"] = 9,
				["wipes"] = 1,
				["best"] = 272.9069999998901,
			},
		},
	},
	[1009] = {
		[744] = {
			["lfr"] = {
				["best"] = 299.365000000002,
				["kills"] = 5,
			},
			["10h"] = {
				["kills"] = 3,
				["wipes"] = 1,
				["best"] = 261.790999999999,
			},
			["10"] = {
				["best"] = 207.081999999995,
				["kills"] = 1,
			},
		},
		[737] = {
			["25"] = {
				["best"] = 343.097999999998,
				["kills"] = 1,
			},
			["lfr"] = {
				["best"] = 200.514000000003,
				["kills"] = 4,
			},
			["10h"] = {
				["kills"] = 3,
				["wipes"] = 3,
				["best"] = 353.613000000001,
			},
			["25h"] = {
				["kills"] = 1,
				["wipes"] = 1,
				["best"] = 366.550000000047,
			},
		},
		[713] = {
			["lfr"] = {
				["best"] = 250.576000000001,
				["kills"] = 5,
			},
			["10h"] = {
				["best"] = 273.961999999999,
				["kills"] = 2,
			},
			["10"] = {
				["best"] = 307.650000000009,
				["kills"] = 1,
			},
		},
		[743] = {
			["25"] = {
				["wipes"] = 2,
			},
			["25h"] = {
				["best"] = 606.23199999996,
				["kills"] = 1,
			},
			["10h"] = {
				["kills"] = 2,
				["wipes"] = 3,
				["best"] = 505.088,
			},
			["lfr"] = {
				["best"] = 364.504000000001,
				["kills"] = 4,
			},
			["10"] = {
				["best"] = 375.380000000005,
				["kills"] = 1,
			},
		},
		[745] = {
			["lfr"] = {
				["best"] = 228.826000000001,
				["kills"] = 5,
			},
			["25h"] = {
				["kills"] = 1,
				["wipes"] = 1,
				["best"] = 504.088999999978,
			},
			["10h"] = {
				["kills"] = 3,
				["wipes"] = 5,
				["best"] = 327.409,
			},
			["10"] = {
				["best"] = 193.907000000007,
				["kills"] = 1,
			},
		},
		[741] = {
			["25"] = {
				["kills"] = 1,
				["wipes"] = 3,
				["best"] = 350.641000000003,
			},
			["lfr"] = {
				["best"] = 269.816000000003,
				["kills"] = 4,
			},
			["10h"] = {
				["kills"] = 3,
				["wipes"] = 5,
				["best"] = 244.879,
			},
			["25h"] = {
				["best"] = 227.214000000036,
				["kills"] = 1,
			},
		},
	},
	[1228] = {
		[1128] = {
			["heroic"] = {
				["best"] = 120.142999999996,
				["kills"] = 52,
			},
			["mythic"] = {
				["kills"] = 27,
				["best"] = 203.744999999995,
				["wipes"] = 3,
			},
			["normal"] = {
				["best"] = 107.489999999998,
				["kills"] = 11,
			},
			["LFR"] = {
				["best"] = 12.86599999998,
				["kills"] = 27,
			},
		},
		[1195] = {
			["heroic"] = {
				["wipes"] = 62,
			},
			["mythic"] = {
				["kills"] = 1,
				["wipes"] = 106,
				["best"] = 209.872999999992,
			},
			["normal"] = {
				["wipes"] = 23,
			},
			["LFR"] = {
				["kills"] = 1,
				["wipes"] = 19,
				["best"] = 111.699999999953,
			},
		},
		[1196] = {
			["heroic"] = {
				["kills"] = 50,
				["wipes"] = 8,
				["best"] = 133.235000000001,
			},
			["mythic"] = {
				["kills"] = 20,
				["wipes"] = 73,
				["best"] = 292.793000000005,
			},
			["normal"] = {
				["best"] = 140.957999999999,
				["kills"] = 13,
			},
			["LFR"] = {
				["kills"] = 27,
				["best"] = 28.1540000000096,
				["wipes"] = 1,
			},
		},
		[971] = {
			["heroic"] = {
				["kills"] = 51,
				["wipes"] = 30,
				["best"] = 161.404,
			},
			["mythic"] = {
				["kills"] = 17,
				["wipes"] = 92,
				["best"] = 201.421000000002,
			},
			["normal"] = {
				["kills"] = 13,
				["best"] = 122.504000000001,
				["wipes"] = 3,
			},
			["LFR"] = {
				["kills"] = 26,
				["wipes"] = 1,
				["best"] = 22.5389999999898,
			},
		},
		[1148] = {
			["heroic"] = {
				["kills"] = 52,
				["best"] = 149.360000000001,
				["wipes"] = 6,
			},
			["mythic"] = {
				["kills"] = 21,
				["wipes"] = 28,
				["best"] = 246.577000000005,
			},
			["normal"] = {
				["kills"] = 18,
				["best"] = 182.319000000003,
				["wipes"] = 8,
			},
			["LFR"] = {
				["kills"] = 23,
				["best"] = 32.5350000000035,
				["wipes"] = 1,
			},
		},
		[1153] = {
			["heroic"] = {
				["kills"] = 48,
				["best"] = 138.463999999993,
				["wipes"] = 14,
			},
			["normal"] = {
				["kills"] = 17,
				["best"] = 131.175000000003,
				["wipes"] = 4,
			},
			["mythic"] = {
				["kills"] = 15,
				["wipes"] = 86,
				["best"] = 269.978999999999,
			},
			["LFR"] = {
				["kills"] = 23,
				["wipes"] = 2,
				["best"] = 19.997000000003,
			},
		},
		[1197] = {
			["heroic"] = {
				["kills"] = 50,
				["wipes"] = 63,
				["best"] = 375.391999999993,
			},
			["mythic"] = {
				["kills"] = 8,
				["wipes"] = 223,
				["best"] = 807.909,
			},
			["normal"] = {
				["kills"] = 14,
				["best"] = 373.807999999997,
				["wipes"] = 38,
			},
			["LFR"] = {
				["best"] = 185.847000000009,
				["kills"] = 22,
			},
		},
	},
	[1136] = {
		[850] = {
			["normal"] = {
				["best"] = 82.56700000001,
				["kills"] = 1,
			},
			["mythic"] = {
				["best"] = 58.5590000000011,
				["kills"] = 9,
			},
			["flex"] = {
				["kills"] = 70,
				["best"] = 110.396999999997,
				["wipes"] = 11,
			},
			["25"] = {
				["best"] = 279.161999999997,
				["kills"] = 5,
			},
			["25h"] = {
				["kills"] = 24,
				["best"] = 221.109000000055,
				["wipes"] = 4,
			},
			["10h"] = {
				["kills"] = 23,
				["wipes"] = 10,
				["best"] = 184.951000000001,
			},
			["lfr"] = {
				["kills"] = 6,
				["wipes"] = 1,
				["best"] = 245.502999999997,
			},
			["heroic"] = {
				["best"] = 24.5070000000014,
				["kills"] = 3,
			},
			["10"] = {
				["kills"] = 8,
				["best"] = 208.452999999994,
				["wipes"] = 1,
			},
		},
		[867] = {
			["normal"] = {
				["kills"] = 1,
				["best"] = 118.016999999993,
				["wipes"] = 1,
			},
			["mythic"] = {
				["best"] = 83.9660000000004,
				["kills"] = 9,
			},
			["flex"] = {
				["kills"] = 64,
				["best"] = 125.536,
				["wipes"] = 5,
			},
			["25"] = {
				["best"] = 288.208999999995,
				["kills"] = 4,
			},
			["25h"] = {
				["kills"] = 27,
				["wipes"] = 11,
				["best"] = 234.583999999974,
			},
			["10h"] = {
				["kills"] = 23,
				["wipes"] = 2,
				["best"] = 226.584000000003,
			},
			["lfr"] = {
				["best"] = 239.246999999989,
				["kills"] = 6,
			},
			["heroic"] = {
				["best"] = 18.0319999999992,
				["kills"] = 3,
			},
			["10"] = {
				["kills"] = 8,
				["best"] = 248.004999999997,
				["wipes"] = 1,
			},
		},
		[869] = {
			["normal"] = {
				["kills"] = 3,
				["best"] = 254.994000000006,
				["wipes"] = 2,
			},
			["mythic"] = {
				["kills"] = 11,
				["wipes"] = 18,
				["best"] = 334.997000000003,
			},
			["flex"] = {
				["kills"] = 52,
				["wipes"] = 32,
				["best"] = 211.398000000016,
			},
			["25"] = {
				["kills"] = 8,
				["wipes"] = 10,
				["best"] = 438.105000000011,
			},
			["25h"] = {
				["kills"] = 23,
				["wipes"] = 338,
				["best"] = 673.135000000009,
			},
			["10h"] = {
				["kills"] = 9,
				["wipes"] = 96,
				["best"] = 553.034,
			},
			["lfr"] = {
				["best"] = 319.859999999986,
				["kills"] = 6,
			},
			["heroic"] = {
				["kills"] = 154,
				["best"] = 91.4759999999988,
				["wipes"] = 13,
			},
			["10"] = {
				["kills"] = 11,
				["wipes"] = 23,
				["best"] = 315.921999999999,
			},
		},
		[856] = {
			["normal"] = {
				["best"] = 99.4239999999991,
				["kills"] = 1,
			},
			["mythic"] = {
				["best"] = 125.254999999997,
				["kills"] = 9,
			},
			["flex"] = {
				["kills"] = 69,
				["best"] = 86.0280000000203,
				["wipes"] = 13,
			},
			["25"] = {
				["best"] = 206.453999999998,
				["kills"] = 5,
			},
			["25h"] = {
				["kills"] = 24,
				["wipes"] = 6,
				["best"] = 219.256999999983,
			},
			["10h"] = {
				["kills"] = 20,
				["wipes"] = 26,
				["best"] = 171.005999999994,
			},
			["lfr"] = {
				["best"] = 253.176000000007,
				["kills"] = 6,
			},
			["heroic"] = {
				["best"] = 25.0669999999991,
				["kills"] = 3,
			},
			["10"] = {
				["kills"] = 10,
				["best"] = 159.199000000001,
				["wipes"] = 2,
			},
		},
		[852] = {
			["normal"] = {
				["best"] = 453.932000000001,
				["kills"] = 1,
			},
			["mythic"] = {
				["kills"] = 9,
				["best"] = 222.994000000006,
				["wipes"] = 1,
			},
			["flex"] = {
				["kills"] = 63,
				["best"] = 187.603999999992,
				["wipes"] = 2,
			},
			["25"] = {
				["best"] = 261.883000000002,
				["kills"] = 1,
			},
			["25h"] = {
				["kills"] = 26,
				["wipes"] = 3,
				["best"] = 220.179,
			},
			["10h"] = {
				["kills"] = 23,
				["wipes"] = 12,
				["best"] = 321.240000000005,
			},
			["lfr"] = {
				["best"] = 254.266000000003,
				["kills"] = 7,
			},
			["heroic"] = {
				["kills"] = 3,
				["best"] = 210.203000000001,
				["wipes"] = 1,
			},
			["10"] = {
				["best"] = 329.669999999998,
				["kills"] = 5,
			},
		},
		[868] = {
			["normal"] = {
				["best"] = 389.755000000005,
				["kills"] = 1,
			},
			["mythic"] = {
				["best"] = 333.248,
				["kills"] = 9,
			},
			["flex"] = {
				["kills"] = 64,
				["best"] = 357.040000000008,
				["wipes"] = 5,
			},
			["25"] = {
				["kills"] = 4,
				["best"] = 479.71100000001,
				["wipes"] = 3,
			},
			["25h"] = {
				["kills"] = 28,
				["wipes"] = 9,
				["best"] = 439.456000000001,
			},
			["10h"] = {
				["kills"] = 22,
				["best"] = 400.323999999993,
				["wipes"] = 16,
			},
			["lfr"] = {
				["kills"] = 6,
				["best"] = 476.023999999998,
				["wipes"] = 1,
			},
			["heroic"] = {
				["best"] = 322.698999999997,
				["kills"] = 3,
			},
			["10"] = {
				["kills"] = 9,
				["wipes"] = 5,
				["best"] = 457.012000000002,
			},
		},
		[864] = {
			["normal"] = {
				["best"] = 121.442999999999,
				["kills"] = 1,
			},
			["25h"] = {
				["kills"] = 27,
				["wipes"] = 5,
				["best"] = 201.015,
			},
			["10h"] = {
				["kills"] = 21,
				["wipes"] = 26,
				["best"] = 190.433999999994,
			},
			["heroic"] = {
				["kills"] = 3,
				["wipes"] = 1,
				["best"] = 26.6550000000025,
			},
			["mythic"] = {
				["best"] = 102.347999999998,
				["kills"] = 9,
			},
			["flex"] = {
				["kills"] = 66,
				["best"] = 124.390000000014,
				["wipes"] = 5,
			},
			["lfr"] = {
				["best"] = 260.347000000009,
				["kills"] = 6,
			},
			["10"] = {
				["kills"] = 10,
				["best"] = 237.536,
				["wipes"] = 2,
			},
		},
		[851] = {
			["normal"] = {
				["kills"] = 3,
				["best"] = 141.685999999987,
				["wipes"] = 1,
			},
			["mythic"] = {
				["best"] = 90.3870000000025,
				["kills"] = 9,
			},
			["flex"] = {
				["kills"] = 68,
				["wipes"] = 17,
				["best"] = 105.449999999997,
			},
			["25"] = {
				["kills"] = 6,
				["best"] = 297.217999999994,
				["wipes"] = 5,
			},
			["25h"] = {
				["kills"] = 21,
				["wipes"] = 20,
				["best"] = 289.5,
			},
			["10h"] = {
				["kills"] = 18,
				["best"] = 254.536999999997,
				["wipes"] = 41,
			},
			["lfr"] = {
				["best"] = 342.809999999998,
				["kills"] = 4,
			},
			["heroic"] = {
				["best"] = 52.5620000000017,
				["kills"] = 3,
			},
			["10"] = {
				["kills"] = 10,
				["best"] = 203.444000000003,
				["wipes"] = 16,
			},
		},
		[853] = {
			["normal"] = {
				["best"] = 229.747999999992,
				["kills"] = 3,
			},
			["mythic"] = {
				["best"] = 190.05799999999,
				["kills"] = 9,
			},
			["flex"] = {
				["kills"] = 48,
				["wipes"] = 16,
				["best"] = 197.224000000017,
			},
			["25"] = {
				["kills"] = 4,
				["wipes"] = 10,
				["best"] = 587.103999999999,
			},
			["25h"] = {
				["kills"] = 46,
				["wipes"] = 215,
				["best"] = 79.1810000000005,
			},
			["10h"] = {
				["kills"] = 14,
				["best"] = 451.118999999999,
				["wipes"] = 29,
			},
			["lfr"] = {
				["kills"] = 5,
				["best"] = 285.698999999964,
				["wipes"] = 1,
			},
			["heroic"] = {
				["kills"] = 3,
				["wipes"] = 2,
				["best"] = 64.2309999999998,
			},
			["10"] = {
				["kills"] = 10,
				["best"] = 315.106,
				["wipes"] = 2,
			},
		},
		[870] = {
			["normal"] = {
				["best"] = 294.349000000017,
				["kills"] = 2,
			},
			["25h"] = {
				["kills"] = 19,
				["wipes"] = 30,
				["best"] = 397.408,
			},
			["10h"] = {
				["kills"] = 20,
				["wipes"] = 38,
				["best"] = 388.009000000006,
			},
			["heroic"] = {
				["best"] = 102.558000000001,
				["kills"] = 3,
			},
			["mythic"] = {
				["best"] = 209.061000000002,
				["kills"] = 9,
			},
			["lfr"] = {
				["best"] = 465.824000000001,
				["kills"] = 3,
			},
			["flex"] = {
				["kills"] = 54,
				["best"] = 197.687000000005,
				["wipes"] = 28,
			},
			["10"] = {
				["kills"] = 4,
				["wipes"] = 5,
				["best"] = 347.788000000001,
			},
		},
		[865] = {
			["normal"] = {
				["best"] = 52.9510000000009,
				["kills"] = 3,
			},
			["mythic"] = {
				["best"] = 35.8270000000048,
				["kills"] = 9,
			},
			["flex"] = {
				["kills"] = 50,
				["wipes"] = 17,
				["best"] = 88.9900000000198,
			},
			["25"] = {
				["kills"] = 4,
				["wipes"] = 5,
				["best"] = 308.663000000001,
			},
			["25h"] = {
				["kills"] = 26,
				["wipes"] = 256,
				["best"] = 290.882000000041,
			},
			["10h"] = {
				["kills"] = 11,
				["wipes"] = 66,
				["best"] = 260.13900000001,
			},
			["lfr"] = {
				["best"] = 169.777000000002,
				["kills"] = 6,
			},
			["heroic"] = {
				["best"] = 16.4199999999983,
				["kills"] = 3,
			},
			["10"] = {
				["kills"] = 17,
				["best"] = 96.9130000000005,
				["wipes"] = 8,
			},
		},
		[866] = {
			["normal"] = {
				["best"] = 136.616999999998,
				["kills"] = 1,
			},
			["mythic"] = {
				["best"] = 79.6399999999994,
				["kills"] = 9,
			},
			["flex"] = {
				["kills"] = 66,
				["best"] = 122.168999999994,
				["wipes"] = 3,
			},
			["25"] = {
				["best"] = 267.423999999999,
				["kills"] = 5,
			},
			["25h"] = {
				["kills"] = 25,
				["best"] = 225.112,
				["wipes"] = 3,
			},
			["10h"] = {
				["kills"] = 22,
				["best"] = 206.736000000004,
				["wipes"] = 3,
			},
			["lfr"] = {
				["best"] = 200.422999999995,
				["kills"] = 6,
			},
			["heroic"] = {
				["kills"] = 4,
				["best"] = 37.3760000000002,
				["wipes"] = 1,
			},
			["10"] = {
				["kills"] = 7,
				["best"] = 257.669999999998,
				["wipes"] = 2,
			},
		},
		[846] = {
			["normal"] = {
				["best"] = 88.832000000024,
				["kills"] = 2,
			},
			["mythic"] = {
				["kills"] = 9,
				["best"] = 73.9660000000004,
				["wipes"] = 1,
			},
			["flex"] = {
				["kills"] = 65,
				["wipes"] = 23,
				["best"] = 77.6929999999993,
			},
			["25"] = {
				["best"] = 235.603999999999,
				["kills"] = 4,
			},
			["25h"] = {
				["kills"] = 26,
				["wipes"] = 39,
				["best"] = 220.691999999999,
			},
			["10h"] = {
				["kills"] = 22,
				["wipes"] = 29,
				["best"] = 197.80799999999,
			},
			["lfr"] = {
				["best"] = 222.253000000001,
				["kills"] = 4,
			},
			["heroic"] = {
				["best"] = 30.369999999999,
				["kills"] = 3,
			},
			["10"] = {
				["kills"] = 10,
				["best"] = 189.322,
				["wipes"] = 2,
			},
		},
		[849] = {
			["normal"] = {
				["best"] = 166.322000000015,
				["kills"] = 1,
			},
			["mythic"] = {
				["best"] = 139.989000000001,
				["kills"] = 9,
			},
			["flex"] = {
				["kills"] = 65,
				["wipes"] = 1,
				["best"] = 129.292,
			},
			["25"] = {
				["best"] = 264.629000000001,
				["kills"] = 3,
			},
			["25h"] = {
				["kills"] = 25,
				["best"] = 243.723999999987,
				["wipes"] = 1,
			},
			["10h"] = {
				["kills"] = 22,
				["wipes"] = 7,
				["best"] = 203.925000000003,
			},
			["lfr"] = {
				["kills"] = 6,
				["wipes"] = 3,
				["best"] = 217.15800000001,
			},
			["heroic"] = {
				["kills"] = 3,
				["best"] = 37.8909999999996,
				["wipes"] = 1,
			},
			["10"] = {
				["kills"] = 6,
				["best"] = 233.982999999993,
				["wipes"] = 1,
			},
		},
	},
	[2296] = {
		[2394] = {
			["normal"] = {
				["best"] = 131.3870000001043,
				["kills"] = 2,
			},
			["heroic"] = {
				["kills"] = 15,
				["wipes"] = 40,
				["best"] = 207.4880000001285,
			},
			["mythic"] = {
				["kills"] = 36,
				["wipes"] = 157,
				["best"] = 271.9809999999707,
			},
			["LFR"] = {
				["best"] = 181.2600000000093,
				["kills"] = 1,
			},
		},
		[2425] = {
			["normal"] = {
				["best"] = 247.3400000000838,
				["kills"] = 2,
			},
			["mythic"] = {
				["kills"] = 36,
				["wipes"] = 277,
				["best"] = 481.8919999999998,
			},
			["heroic"] = {
				["kills"] = 28,
				["wipes"] = 14,
				["best"] = 234.9100000000001,
			},
			["LFR"] = {
				["best"] = 249.3789999999572,
				["kills"] = 1,
			},
		},
		[2418] = {
			["normal"] = {
				["best"] = 163.3060000000987,
				["kills"] = 2,
			},
			["heroic"] = {
				["kills"] = 13,
				["wipes"] = 2,
				["best"] = 216.9720000000671,
			},
			["mythic"] = {
				["kills"] = 36,
				["wipes"] = 49,
				["best"] = 236.818000000203,
			},
			["LFR"] = {
				["best"] = 268.685999999987,
				["kills"] = 1,
			},
		},
		[2426] = {
			["normal"] = {
				["best"] = 237.6380000000354,
				["kills"] = 2,
			},
			["heroic"] = {
				["kills"] = 15,
				["wipes"] = 6,
				["best"] = 299.8179999999702,
			},
			["mythic"] = {
				["kills"] = 34,
				["wipes"] = 61,
				["best"] = 453.2839999999997,
			},
			["LFR"] = {
				["best"] = 322.5219999999972,
				["kills"] = 1,
			},
		},
		[2420] = {
			["normal"] = {
				["best"] = 137.7700000000186,
				["kills"] = 2,
			},
			["mythic"] = {
				["kills"] = 37,
				["wipes"] = 24,
				["best"] = 255.6010000000242,
			},
			["heroic"] = {
				["kills"] = 13,
				["wipes"] = 10,
				["best"] = 172.7849999999162,
			},
		},
		[2428] = {
			["normal"] = {
				["kills"] = 2,
				["wipes"] = 1,
				["best"] = 126.622999999905,
			},
			["mythic"] = {
				["kills"] = 54,
				["wipes"] = 10,
				["best"] = 216.2520000000004,
			},
			["heroic"] = {
				["kills"] = 12,
				["wipes"] = 3,
				["best"] = 160.4180000000633,
			},
		},
		[2429] = {
			["normal"] = {
				["best"] = 155.6410000000615,
				["kills"] = 2,
			},
			["mythic"] = {
				["kills"] = 58,
				["best"] = 179.366,
				["wipes"] = 4,
			},
			["heroic"] = {
				["kills"] = 12,
				["wipes"] = 5,
				["best"] = 165.9110000000801,
			},
		},
		[2422] = {
			["normal"] = {
				["best"] = 146.3950000000186,
				["kills"] = 2,
			},
			["heroic"] = {
				["kills"] = 13,
				["wipes"] = 3,
				["best"] = 177.630999999994,
			},
			["mythic"] = {
				["kills"] = 39,
				["wipes"] = 16,
				["best"] = 259.0139999999665,
			},
			["LFR"] = {
				["kills"] = 1,
				["wipes"] = 1,
				["best"] = 217.9440000000177,
			},
		},
		[2393] = {
			["normal"] = {
				["best"] = 99.11399999982677,
				["kills"] = 2,
			},
			["mythic"] = {
				["kills"] = 54,
				["wipes"] = 8,
				["best"] = 177.5669999999991,
			},
			["heroic"] = {
				["kills"] = 16,
				["best"] = 163.0249999999069,
				["wipes"] = 3,
			},
			["LFR"] = {
				["best"] = 184.5749999999534,
				["kills"] = 1,
			},
		},
		[2424] = {
			["normal"] = {
				["best"] = 260.8430000001099,
				["kills"] = 2,
			},
			["mythic"] = {
				["kills"] = 36,
				["wipes"] = 209,
				["best"] = 571.4479999998584,
			},
			["heroic"] = {
				["kills"] = 30,
				["wipes"] = 69,
				["best"] = 281.8340000000026,
			},
		},
	},
	[2522] = {
		[2500] = {
			["heroic"] = {
				["best"] = 186.9329999999609,
				["kills"] = 15,
			},
			["mythic"] = {
				["kills"] = 21,
				["wipes"] = 5,
				["best"] = 259.0539999999746,
			},
		},
		[2491] = {
			["heroic"] = {
				["best"] = 232.6720000000205,
				["kills"] = 14,
			},
			["normal"] = {
				["best"] = 298.3800000000047,
				["kills"] = 6,
			},
			["mythic"] = {
				["kills"] = 17,
				["wipes"] = 107,
				["best"] = 411.4619999999995,
			},
		},
		[2499] = {
			["heroic"] = {
				["kills"] = 12,
				["wipes"] = 30,
				["best"] = 574.8320000000531,
			},
			["mythic"] = {
				["kills"] = 6,
				["wipes"] = 425,
				["best"] = 752.1100000000006,
			},
			["normal"] = {
				["kills"] = 4,
				["best"] = 635.4610000000102,
				["wipes"] = 6,
			},
		},
		[2486] = {
			["heroic"] = {
				["best"] = 136.7669999999926,
				["kills"] = 16,
			},
			["normal"] = {
				["best"] = 178.8680000000168,
				["kills"] = 1,
			},
			["mythic"] = {
				["kills"] = 27,
				["wipes"] = 6,
				["best"] = 145.9450000000652,
			},
		},
		[2480] = {
			["heroic"] = {
				["best"] = 139.6670000000158,
				["kills"] = 17,
			},
			["normal"] = {
				["best"] = 149.4230000000098,
				["kills"] = 2,
			},
			["mythic"] = {
				["kills"] = 33,
				["best"] = 133.4079999999995,
				["wipes"] = 2,
			},
		},
		[2502] = {
			["heroic"] = {
				["kills"] = 15,
				["wipes"] = 15,
				["best"] = 185.6639999999898,
			},
			["mythic"] = {
				["kills"] = 7,
				["wipes"] = 82,
				["best"] = 344.2930000000633,
			},
			["normal"] = {
				["kills"] = 6,
				["wipes"] = 3,
				["best"] = 210.0669999999809,
			},
		},
		[2482] = {
			["heroic"] = {
				["kills"] = 13,
				["best"] = 209.564000000013,
				["wipes"] = 1,
			},
			["mythic"] = {
				["kills"] = 21,
				["wipes"] = 9,
				["best"] = 306.0369999999821,
			},
			["normal"] = {
				["kills"] = 6,
				["best"] = 224.9089999999851,
				["wipes"] = 1,
			},
		},
		[2493] = {
			["heroic"] = {
				["kills"] = 20,
				["wipes"] = 21,
				["best"] = 270.9099999999162,
			},
			["mythic"] = {
				["kills"] = 17,
				["wipes"] = 56,
				["best"] = 426.9590000000026,
			},
			["normal"] = {
				["kills"] = 6,
				["wipes"] = 1,
				["best"] = 329.1380000000354,
			},
		},
	},
}
