
OmniCCDB = {
	["global"] = {
		["dbVersion"] = 6,
		["addonVersion"] = "10.2.5",
	},
	["profileKeys"] = {
		["Hitko - Area 52"] = "Default",
		["Hitkodekay - Azralon"] = "Hitko",
		["Hítko - Azralon"] = "Default",
		["Hiitko - Azralon"] = "Default",
		["Hitelele - Azralon"] = "Default",
		["Hitkodh - Azralon"] = "Hitko",
	},
	["profiles"] = {
		["Default"] = {
			["themes"] = {
				["Default"] = {
					["textStyles"] = {
						["soon"] = {
						},
						["minutes"] = {
						},
						["seconds"] = {
						},
					},
				},
				["Plater Nameplates Theme"] = {
					["textStyles"] = {
						["seconds"] = {
						},
						["minutes"] = {
						},
						["soon"] = {
						},
					},
					["enableText"] = false,
				},
			},
			["rules"] = {
				{
					["enabled"] = false,
					["patterns"] = {
						"Aura", -- [1]
						"Buff", -- [2]
						"Debuff", -- [3]
					},
					["name"] = "Auras",
					["id"] = "auras",
				}, -- [1]
				{
					["enabled"] = false,
					["patterns"] = {
						"Plate", -- [1]
					},
					["name"] = "Unit Nameplates",
					["id"] = "plates",
				}, -- [2]
				{
					["enabled"] = false,
					["patterns"] = {
						"ActionButton", -- [1]
						"MultiBar", -- [2]
					},
					["name"] = "Action Bars",
					["id"] = "actions",
				}, -- [3]
				{
					["id"] = "Plater Nameplates Rule",
					["patterns"] = {
						"PlaterMainAuraIcon", -- [1]
						"PlaterSecondaryAuraIcon", -- [2]
						"ExtraIconRowIcon", -- [3]
					},
					["theme"] = "Plater Nameplates Theme",
					["priority"] = 4,
				}, -- [4]
			},
		},
		["Hitko"] = {
			["rules"] = {
				{
					["patterns"] = {
						"LossOfControl", -- [1]
						"TotemFrame", -- [2]
					},
					["id"] = "Ignore",
					["priority"] = 1,
					["theme"] = "Ignore",
				}, -- [1]
				{
					["patterns"] = {
						"PlaterMainAuraIcon", -- [1]
						"PlaterSecondaryAuraIcon", -- [2]
						"ExtraIconRowIcon", -- [3]
					},
					["id"] = "Plater Nameplates Rule",
					["priority"] = 2,
					["theme"] = "Plater Nameplates Theme",
				}, -- [2]
			},
			["themes"] = {
				["Plater Nameplates Theme"] = {
					["textStyles"] = {
						["soon"] = {
							["b"] = 0.2117647230625153,
							["scale"] = 1,
							["g"] = 0.05098039656877518,
							["r"] = 0.7411764860153198,
						},
						["minutes"] = {
							["scale"] = 0.75,
						},
						["seconds"] = {
							["b"] = 0,
							["r"] = 0.988235354423523,
						},
						["hours"] = {
							["r"] = 0.7019608020782471,
							["g"] = 0.7019608020782471,
							["b"] = 0.7019608020782471,
						},
						["controlled"] = {
							["scale"] = 1,
						},
					},
					["tenthsDuration"] = 1,
					["minSize"] = 0,
					["mmSSDuration"] = 600,
					["effect"] = "none",
					["minDuration"] = 0,
				},
				["Default"] = {
					["textStyles"] = {
						["soon"] = {
							["b"] = 0.2117647230625153,
							["scale"] = 1,
							["g"] = 0.05098039656877518,
							["r"] = 0.7411764860153198,
						},
						["minutes"] = {
							["scale"] = 0.75,
						},
						["seconds"] = {
							["b"] = 0,
							["r"] = 0.988235354423523,
						},
						["charging"] = {
							["a"] = 0.800000011920929,
							["b"] = 0.3019607843137255,
						},
						["controlled"] = {
							["scale"] = 1,
						},
					},
					["minDuration"] = 0,
					["tenthsDuration"] = 1,
					["minSize"] = 0,
					["mmSSDuration"] = 600,
					["effect"] = "none",
					["spiralOpacity"] = 1.00999997742474,
				},
				["Ignore"] = {
					["textStyles"] = {
						["soon"] = {
							["b"] = 0.2117647230625153,
							["scale"] = 1,
							["g"] = 0.05098039656877518,
							["r"] = 0.7411764860153198,
						},
						["minutes"] = {
							["scale"] = 0.75,
						},
						["seconds"] = {
							["b"] = 0,
							["r"] = 0.988235354423523,
						},
						["hours"] = {
							["r"] = 0.7019608020782471,
							["g"] = 0.7019608020782471,
							["b"] = 0.7019608020782471,
						},
						["controlled"] = {
							["scale"] = 1,
						},
					},
					["tenthsDuration"] = 1,
					["minSize"] = 0,
					["mmSSDuration"] = 600,
					["effect"] = "none",
					["spiralOpacity"] = 1,
					["minDuration"] = 0,
				},
			},
		},
	},
}
OmniCC4Config = {
	["engine"] = "AniUpdater",
	["groupSettings"] = {
		["PlaterNameplates Blacklist"] = {
			["enabled"] = false,
			["styles"] = {
				["minutes"] = {
				},
				["soon"] = {
				},
				["seconds"] = {
				},
				["hours"] = {
				},
				["charging"] = {
				},
				["controlled"] = {
				},
			},
			["tenthsDuration"] = 0,
			["minSize"] = 0.5,
			["minEffectDuration"] = 30,
			["mmSSDuration"] = 0,
			["minDuration"] = 2,
		},
		["base"] = {
			["enabled"] = true,
			["fontFace"] = "Fonts\\FRIZQT__.TTF",
			["fontSize"] = 16,
			["effect"] = "none",
			["minDuration"] = 2.5,
			["minEffectDuration"] = 30,
			["minSize"] = 0.5,
			["spiralOpacity"] = 1.00999997742474,
			["yOff"] = 0,
			["xOff"] = 0,
			["tenthsDuration"] = 0,
			["fontOutline"] = "OUTLINE",
			["anchor"] = "CENTER",
			["mmSSDuration"] = 90,
			["scaleText"] = true,
			["styles"] = {
				["soon"] = {
					["a"] = 1,
					["r"] = 0.988235294117647,
					["scale"] = 1,
					["g"] = 1,
					["b"] = 0,
				},
				["seconds"] = {
					["a"] = 1,
					["r"] = 1,
					["scale"] = 1,
					["g"] = 1,
					["b"] = 0.101960784313725,
				},
				["minutes"] = {
					["a"] = 1,
					["r"] = 1,
					["scale"] = 1,
					["g"] = 1,
					["b"] = 1,
				},
				["hours"] = {
					["a"] = 1,
					["r"] = 0.7,
					["scale"] = 0.75,
					["g"] = 0.7,
					["b"] = 0.7,
				},
				["charging"] = {
					["a"] = 0.8,
					["r"] = 0.8,
					["scale"] = 0.75,
					["g"] = 1,
					["b"] = 0.3,
				},
				["controlled"] = {
					["a"] = 1,
					["r"] = 1,
					["scale"] = 1.5,
					["g"] = 0.1,
					["b"] = 0.1,
				},
			},
		},
		["Ignore"] = {
			["enabled"] = false,
			["fontFace"] = "Fonts\\FRIZQT__.TTF",
			["styles"] = {
				["seconds"] = {
					["a"] = 1,
					["r"] = 1,
					["scale"] = 1,
					["g"] = 1,
					["b"] = 0.1,
				},
				["minutes"] = {
					["a"] = 1,
					["r"] = 1,
					["scale"] = 1,
					["g"] = 1,
					["b"] = 1,
				},
				["soon"] = {
					["a"] = 1,
					["r"] = 1,
					["scale"] = 1.5,
					["g"] = 0.1,
					["b"] = 0.1,
				},
				["hours"] = {
					["a"] = 1,
					["r"] = 0.7,
					["scale"] = 0.75,
					["g"] = 0.7,
					["b"] = 0.7,
				},
				["charging"] = {
					["a"] = 0.8,
					["r"] = 0.8,
					["scale"] = 0.75,
					["g"] = 1,
					["b"] = 0.3,
				},
				["controlled"] = {
					["a"] = 1,
					["r"] = 1,
					["scale"] = 1.5,
					["g"] = 0.1,
					["b"] = 0.1,
				},
			},
			["effect"] = "pulse",
			["scaleText"] = true,
			["mmSSDuration"] = 0,
			["anchor"] = "CENTER",
			["spiralOpacity"] = 1,
			["minDuration"] = 2,
			["xOff"] = 0,
			["tenthsDuration"] = 0,
			["fontOutline"] = "OUTLINE",
			["minSize"] = 0.5,
			["minEffectDuration"] = 30,
			["yOff"] = 0,
			["fontSize"] = 18,
		},
	},
	["groups"] = {
		{
			["id"] = "Ignore",
			["rules"] = {
				"LossOfControl", -- [1]
				"TotemFrame", -- [2]
			},
			["enabled"] = true,
		}, -- [1]
		{
			["id"] = "PlaterNameplates Blacklist",
			["rules"] = {
				"PlaterMainAuraIcon", -- [1]
				"PlaterSecondaryAuraIcon", -- [2]
				"ExtraIconRowIcon", -- [3]
			},
			["enabled"] = true,
		}, -- [2]
	},
	["version"] = "8.2.5",
}
