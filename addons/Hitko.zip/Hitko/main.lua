local LSM = LibStub("LibSharedMedia-3.0");

-- StatusBars
LSM:Register("statusbar","Hitko Bar", [[Interface\AddOns\Hitko\Texture\HitkoBar.tga]]);
LSM:Register("statusbar","Hitko Bar Dark", [[Interface\AddOns\Hitko\Texture\HitkoBarDark.tga]]);

-- Sounds
LSM:Register("sound","Afflicted", [[Interface\AddOns\Hitko\Sounds\Afflicted.ogg]])
LSM:Register("sound","Casting", [[Interface\AddOns\Hitko\Sounds\Casting.ogg]])
LSM:Register("sound","CC", [[Interface\AddOns\Hitko\Sounds\CC.ogg]])
LSM:Register("sound","Cheat Death", [[Interface\AddOns\Hitko\Sounds\CheatDeath.ogg]])
LSM:Register("sound","Cooldown Reduction", [[Interface\AddOns\Hitko\Sounds\CooldownReduction.ogg]])
LSM:Register("sound","Damage", [[Interface\AddOns\Hitko\Sounds\Damage.ogg]])
LSM:Register("sound","Dispell", [[Interface\AddOns\Hitko\Sounds\Dispell.ogg]])
LSM:Register("sound","External", [[Interface\AddOns\Hitko\Sounds\External.ogg]])
LSM:Register("sound","Incorporeal", [[Interface\AddOns\Hitko\Sounds\Incorporeal.ogg]])
LSM:Register("sound","Proc", [[Interface\AddOns\Hitko\Sounds\Proc.ogg]])
LSM:Register("sound","Raid Cooldown", [[Interface\AddOns\Hitko\Sounds\RaidCooldown.ogg]])
LSM:Register("sound","Taunt", [[Interface\AddOns\Hitko\Sounds\Taunt.ogg]])
LSM:Register("sound","Taunted", [[Interface\AddOns\Hitko\Sounds\Taunted.ogg]])
LSM:Register("sound","Parried", [[Interface\AddOns\Hitko\Sounds\Parried.ogg]])

-- Fonts
LSM:Register("font","Hitko Font",[[Interface\AddOns\Hitko\Fonts\INTER-EXTRABOLD.ttf]])